<?php

$ModulePath = "C:\\xampp\htdocs\Scheduler\Schedule_Task_PHP.ps1";

if(isset($_POST['weekly_uploadScriptFile'])){
    $f = $_FILES['weekly_scriptFile'];
    $sz = (int)$f['size'];
    $sz = number_format($sz / 1024,2);

    $uploadPath = 'C:/xampp/htdocs/Scheduler/scripts/';
    $ext = pathinfo($_FILES['weekly_scriptFile']['name'],PATHINFO_EXTENSION);
    $filename = $_FILES['weekly_scriptFile']['name'];
    $scriptPath = $uploadPath.$filename;			
    
    $allowed_csv_ext=array("ps1");
    if ( !in_array($ext, $allowed_csv_ext)) {		
        echo '
        <script>
            alert("Please upload file in .ps1 format");
        </script>
        ';
        header("Refresh:1");
    }else{
        if(file_exists($scriptPath)){
            // echo '
            // <script>
            //     alert("File with this name already exists");
            // </script>
            // ';
        }else{
            move_uploaded_file($_FILES['weekly_scriptFile']['tmp_name'], $scriptPath);
        }
    }
}

if(isset($_POST['scheduleWeekly'])){
    $scriptAbsPath = realpath($_POST['weekly_scriptPathDisplay']);
    if($scriptAbsPath){
        $taskName = $_POST['weekly_taskName'];
        $weekly_date = $_POST['weekly_date'];
        $weekly_time = $_POST['weekly_time'];
        $Interval = $_POST['weekly_interval'];
        $wds = '"'.implode(' ',$_POST['weekly_days']).'"';

        $command = 'powershell.exe -File "'.$ModulePath.'" -Path "'.$scriptAbsPath.'" -TaskName "'.$taskName.'" -Interval '.$Interval.' -Duration Weekly -WeekDays '.$wds.' -Time "'.$weekly_date.' '.$weekly_time.'"';
        echo $command;
        
        exec($command, $output, $err);
        if($err){
            $W_MSG = '<div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="row" style="align-items: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                    <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                    <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                </svg>
                <strong>Failed!</strong> Task Failed, Try again.
            </div>
          </div>';
        }else{
            $W_MSG = '<div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="row" style="align-items: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                    <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                    <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                </svg>
                <strong>Success!</strong> Weekly Task Scheduled Successfully.
            </div>
          </div>';
        }
        
    }
}
?>
<!-- modal for script file -->
<div class="modal fade" id="weekly_scriptFileModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <p><strong><span class="lead text-dange">*</span> Upload weekly Script File</strong></p>
                <div class="form-group">
                    <input type="file" name="weekly_scriptFile" id="weekly_scriptFile" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="weekly_uploadScriptFile" class="btn btn-info">Upload</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- modal for server file -->
<div class="modal fade" id="weekly_serverFileModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <p><strong>Upload Server File</strong></p>
                <div class="form-group">
                    <input type="file" name="weekly_serverFile" id="weekly_serverFile">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="weekly_uploadServerFile" class="btn btn-info">Upload</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>


<!-- MAIN CODE -->
<div class="container">
    <?php if(isset($W_MSG)){echo '<div class="message_box">'.$W_MSG.'</div>';}?>
    <div class="task_title">
        <span style="margin-right: 10px;">
            <i data-feather="clock" class="font-weight-bold"></i>
        </span>
        <h2 class="lead font-weight-bold">Schedule a Task for Weekly</h2>
    </div>      
    <hr>
    <form action="" method="POST" id="weekly_form">
    <p><strong class="lead text-danger">*</strong> Script Path</p>
    <p class="text-small">Provide absolute path to script or browse to upload file.</p>
    <div class="row form-group">
        <div class="col col-md-10">
            <input type="text" name="weekly_scriptPathDisplay" id="weekly_scriptPathDisplay" class="form-control" value="<?php if(isset($scriptPath)){echo $scriptPath;}?>" required>
        </div>
        <div class="col col-md-2">
            <a class="btn btn-light" data-toggle="modal" data-target="#weekly_scriptFileModal">Browse</a>
        </div>
    </div>
    <p>Servers File</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="weekly_serverPathDisplay" id="weekly_serverPathDisplay" class="form-control" value="<?php if(isset($handle)){echo $handle;}?>">
        </div>
        <div class="col col-md-3">
            <a class="btn btn-light" data-toggle="modal" data-target="#weekly_serverFileModal">Upload Server File</a>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-6 form-group">
            <p><strong class="lead text-danger">*</strong> Task Name</p>
            <input type="text" name="weekly_taskName" id="weekly_taskName" class="form-control" required />
        </div>
        <div class="col col-md-6 form-group">
            <p class=""><strong class="lead text-danger">*</strong> Select Date and Time (UTC +5:30):</p>
            <div class="row form-group pl-3">
                <input type="date" name="weekly_date" id="weekly_date" class="form-control col col-md-7" required>
                <input type="time" name="weekly_time" id="weekly_time" class="form-control col col-md-5" required>
            </div>
        </div>
    </div>
    <div class="row form-group">
        <p class="col col-md-3"><strong class="lead text-danger">*</strong> Recur Every:</p>
        <input type="number" name="weekly_interval" id="weekly_interval" min="1" value="1" class="col col-md-2 form-control" required>
        <p class="col col-md-3">weeks</p> 
    </div>
    <p>On:</p>
    <div class="row form-group px-3">
        <?php
            $weekDays = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
            for ($wd=0; $wd < count($weekDays); $wd++) { 
                echo '
                <div class="form-check col col-md-3">
                    <input class="form-check-input" name="weekly_days[]" type="checkbox" value="'.$weekDays[$wd].'" id="weekly_day'.$wd.'">
                    <label class="form-check-label" for="weekly_day'.$wd.'">
                    '.$weekDays[$wd].'
                    </label>
                </div>';
            }
        ?>
    </div>    
    <div class="row" style="margin-top: 60px;">
        <button type="submit" value="#" name="scheduleWeekly" class="btn btn-primary mr-3">Schedule</button>
        <button type="reset" class="btn btn-light">Cancel</button>
    </div>
    </form>
</div>

<script>
    let checkState = false;
    let w_form = document.getElementById('weekly_form');
    w_form.addEventListener('submit',(e)=>{
        e.preventDefault();
        for (let w = 0; w < 7; w++) {
            const eID = `weekly_day${w}`
            let cb = document.getElementById(eID)
            if(cb.checked){checkState = true}  
        }
        if(!checkState){alert('Please select atleast 1 Day.')}
        else{w_form.submit();}
    });
</script>