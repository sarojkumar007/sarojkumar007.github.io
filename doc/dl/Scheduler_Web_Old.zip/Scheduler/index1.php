<?php
    if(isset($_POST['uploadServerFile'])){
        $f = $_FILES['serverFile'];
        $sz = (int)$f['size'];
        $sz = number_format($sz / 1024,2);
        $handle = "{$f['name']} ({$sz} KB)";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduler</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <style>
        body{padding: 60px;}
        .container{padding: 20px;}
    </style>
</head>
<body>

    <!-- pop ups -->
    <div class="modal fade" id="serverFileModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <p><strong>Upload Server File</strong></p>
                    <div class="form-group">
                        <input type="file" name="serverFile" id="serverFile">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="uploadServerFile" class="btn btn-info">Upload</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </form>
            </div>
        </div>
    </div>
    <!-- main code -->
    <div class="container bordered">
        <ul class="nav nav-tabs" id="schedulerTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link" id="once-tab" data-toggle="tab" href="#once" role="tab" aria-controls="once" aria-selected="false">Once Task</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" id="daily-tab" data-toggle="tab" href="#daily" role="tab" aria-controls="daily" aria-selected="true">Daily Task</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="weekly-tab" data-toggle="tab" href="#weekly" role="tab" aria-controls="weekly" aria-selected="false">Weekly Task</a>
            </li>
            <!-- <li class="nav-item">
                <a class="nav-link" id="monthly-tab" data-toggle="tab" href="#monthly" role="tab" aria-controls="monthly" aria-selected="false">Monthly Task</a>
            </li> -->
        </ul>
        <div class="tab-content" id="schedulerTabContent">
            <div class="tab-pane fade " id="once" role="tabpanel" aria-labelledby="once-tab">
                <div class="container">
                    <h3 class="lead">Schedule a Task for Once</h3>
                    <hr>
                    <form action="#" method="POST" enctype="multipart/form-data">
                    <p>Script Path</p>
                    <div class="row form-group">
                        <div class="col col-md-10">
                            <input type="text" name="scriptPathDisplay" id="scriptPathDisplay" class="form-control">
                        </div>
                        <div class="col col-md-2">
                            <input style="display: none;" type="file" name="scriptPath" id="scriptPath">
                            <label for="scriptPath">
                                <a class="btn btn-light">Browse</a>
                            </label>
                        </div>
                    </div>
                    <p>Servers File</p>
                    <div class="row form-group">
                        <div class="col col-md-9">
                            <input type="text" name="serverPathDisplay" id="serverPathDisplay" class="form-control" value="<?php if(isset($handle)){echo $handle;}?>">
                        </div>
                        <div class="col col-md-3">
                            <a class="btn btn-light" data-toggle="modal" data-target="#serverFileModal">Upload Server File</a>
                        </div>
                    </div>
                    <div class="row form-group">
                        <p for="" class="col col-md-3">Select Date and Time:</p>
                    </div>
                    <div class="row form-group pl-3">
                        <input type="date" name="once_date" id="once_date" class="form-control col col-md-3 mr-3">
                        <input type="time" name="once_time" id="once_time" class="form-control col col-md-3">
                    </div>
                    <!-- <div class="form-group">
                        <h4>Settings:</h4>
                        <p class="text-muted">If task fails, restart every: 5 Minutes for 1 times</p>
                    </div> -->
                    <div class="row" style="margin-top: 60px;">
                        <button type="submit" class="btn btn-primary mr-3">Schedule</button>
                        <button type="reset" class="btn btn-light">Cancel</button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="tab-pane fade show active" id="daily" role="tabpanel" aria-labelledby="daily-tab">Daily</div>


            
            <div class="tab-pane fade" id="weekly" role="tabpanel" aria-labelledby="weekly-tab">Weekly</div>
            <!-- <div class="tab-pane fade" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">Monthly</div> -->
        </div>
    </div>
    <script src="./js/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script>
    // https://getbootstrap.com/docs/4.0/components/navs/#javascript-behavior
    </script>
</body>
</html>