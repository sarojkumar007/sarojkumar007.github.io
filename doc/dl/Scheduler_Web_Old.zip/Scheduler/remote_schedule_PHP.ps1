Param(
    [String]$SERVERS_FILE,
    [Parameter(Mandatory=$true)][string]$Path,
    [Parameter(Mandatory=$true)][string]$TaskName,
    [Parameter(Mandatory=$true)][ValidateSet("Once","Daily","Weekly","Monthly")][String]$Duration,
    [String]$Interval,
    [String]$WeekDays,
    [validateSet("January","February","March","April","May","June","July","August","September","October","November","December")][String[]]$Months,
    [Parameter(Mandatory=$true)][String]$Time,
    [ValidateSet("Indefinitely","15 Minutes","30 Minutes","1 Hour","12 Hours","1 Day")][String]$RecurEvery,
    [ValidateSet("5 Minutes","10 Minutes","15 Minutes","30 Minutes","1 Hour")][String]$RecurInterval
)

# Script that will be copied to the remote server
$SCRIPT="C:\xampp\htdocs\Scheduler\Schedule_Task_PHP.ps1"
########################################################
$ModuleFileName = Split-Path $SCRIPT -Leaf
$SriptFileName = Split-Path -Path $Path -Leaf
$SERVERS=Get-Content $SERVERS_FILE
Foreach ($SERVER in $SERVERS)
{
    If(Test-WSMan -ComputerName $SERVER -EA 0)
    {
        $ModulePath = "\\$SERVER\C$\TaskScheduler\$ModuleFileName"
        $ScriptPath = "\\$SERVER\C$\TaskScheduler\$ScriptFileName"
        "Configuring the task on server $SERVER..."
        Copy-Item -Path "$SCRIPT" -Destination $ModulePath -cn $SERVER -Force
        Copy-Item -Path "$Path" -Destination $ScriptPath -cn $SERVER -Force
        Invoke-Command -ComputerName $SERVER -FilePath $ScriptPath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$WeekDays,$Time,$RecurEvery,$RecurInterval)
    }
    Else 
    {
        write-host "$SERVER is not available"
    }
}
