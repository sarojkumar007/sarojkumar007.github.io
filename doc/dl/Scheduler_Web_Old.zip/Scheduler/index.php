<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduler</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <style>
        /* Temp CSS */
        body{padding: 10px 40px;}
        .container{padding: 20px;}
        /* ------ */
        .btn-light{border: 1px solid #999 !important;}
        .task_title{
            display: flex;
            align-items: center;
            /* padding: 10px 15px;
            background-color: #f7f7f7;
            border: 2px solid #eee; */
            border-radius: 4px;
        }
        .task_title span{display: flex; justify-content: center; align-items:center;fill: currentColor;}
        .task_title h2{margin: 0;}
        .feather {
            width: 24px;
            height: 24px;
            stroke: currentColor;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
            fill: none;
        }
        .form-check input{
            width: 18px;
            height: 18px;
        }
        .form-check label{margin-left: 8px;user-select: none;}
    </style>
</head>
<body>
    <!-- main code -->
    <div class="container bordered">
        <ul class="nav nav-tabs" id="schedulerTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="once-tab" data-toggle="tab" href="#once" role="tab" aria-controls="once" aria-selected="true">Once Task</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="daily-tab" data-toggle="tab" href="#daily" role="tab" aria-controls="daily" aria-selected="false">Daily Task</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="weekly-tab" data-toggle="tab" href="#weekly" role="tab" aria-controls="weekly" aria-selected="false">Weekly Task</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="monthly-tab" data-toggle="tab" href="#monthly" role="tab" aria-controls="monthly" aria-selected="false">Monthly Task</a>
            </li>
        </ul>
        <div class="tab-content" id="schedulerTabContent">
            <div class="tab-pane fade show active" id="once" role="tabpanel" aria-labelledby="once-tab">
                <?php include('tab_once.php'); ?>
            </div>
            <div class="tab-pane fade" id="daily" role="tabpanel" aria-labelledby="daily-tab">
                <?php include('tab_daily.php'); ?>
            </div>
            <div class="tab-pane fade" id="weekly" role="tabpanel" aria-labelledby="weekly-tab">
                <?php include('tab_weekly.php'); ?>
            </div>
            <div class="tab-pane fade" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                <p>To be updated ...</p>
            </div>
        </div>
    </div>
    <script src="./js/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/feather-icons"></script>

    <script>
      feather.replace();
    // https://getbootstrap.com/docs/4.0/components/navs/#javascript-behavior
    </script>
</body>
</html>