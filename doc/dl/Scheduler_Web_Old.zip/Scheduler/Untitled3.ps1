﻿Param(
    [String]$SERVERS_FILE

    [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)][string]$Path,
    [Parameter(Mandatory=$true)][string]$TaskName,
    [Parameter(Mandatory=$true)][ValidateSet("Once","Daily","Weekly","Monthly")][String]$Duration,
    [String]$Interval,
    [String]$WeekDays,
    [validateSet("January","February","March","April","May","June","July","August","September","October","November","December")][String[]]$Months,

    [Parameter(Mandatory=$true)][String]$Time,
    [ValidateSet("Indefinitely","15 Minutes","30 Minutes","1 Hour","12 Hours","1 Day")][String]$RecurEvery,
    [ValidateSet("5 Minutes","10 Minutes","15 Minutes","30 Minutes","1 Hour")][String]$RecurInterval
)

# Script that will be copied to the remote server
$SCRIPT="C:\xampp\htdocs\Scheduler\Schedule_Task_PHP.ps1"
########################################################
$REMOTE_FILE=$SCRIPT -replace ":","$"
$SERVERS=Get-Content $SERVERS_FILE
Foreach ($SERVER in $SERVERS)
{
    If(Test-WSMan -ComputerName $SERVER -EA 0)
    {
        "Configuring the task on server $SERVER..."
        Copy-Item -Path "$SCRIPT" -Destination "\\$SERVER\$REMOTE_FILE"
        Invoke-Command -ComputerName $SERVER -ScriptBlock {
           "\\$SERVER\$REMOTE_FILE" -




        }
    }
    Else 
    {
        "$SERVER is not available"
    }
}




$sess = New-CimSession -ComputerName 172.31.37.17


Invoke-Command -ComputerName localhost -ScriptBlock { 
    C:\xampp\htdocs\Scheduler\test2.ps1 -uName "abc" -pw "sadsadasd" 
}
$sess = New-CimSession -ComputerName localhost
Get-ScheduledTask -CimSession $sess -TaskName 't01' | Start-ScheduledTask

Test-WSMan -ComputerName asdsds




C:\xampp\htdocs\Scheduler\remote_schedule_PHP.ps1 -SERVERS_FILE "C:\xampp\htdocs\Scheduler\servers\pingable.txt" -Path "C:\xampp\htdocs\Scheduler\test2.ps1" -TaskName "Demo1" -Duration Once -Time "12-7-2021 9:20"


New-Item -Path "\\"
New-Item -Path "\\127.0.0.1\C$\dem\demo.txt" -Force

$uName = "abc"
$pw = "1234"
$res = Invoke-Command -FilePath "C:\xampp\htdocs\Scheduler\test2.ps1" -ArgumentList ($uName,$pw)