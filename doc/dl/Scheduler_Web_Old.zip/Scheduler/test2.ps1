Param(
[String]$uName,
[String]$pw
)
write-host  $uName
write-host  $pw
start-sleep -seconds 10