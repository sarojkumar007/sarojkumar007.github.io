﻿# Code By Mahima

$Sta = New-ScheduledTaskAction cmd
$trg = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2)

$local= (Get-LocalUser).name

$l = "Administrators"

if($local -contains $l)
{
    $STPrin = New-ScheduledTaskPrincipal -UserId $l -RunLevel Highest
    Register-ScheduledTask New_Remote4 -Action $Sta -Principal $STPrin -Trigger $trg
}
else
{
    $STPrin = New-ScheduledTaskPrincipal -groupid $l -RunLevel Highest
    Register-ScheduledTask New_Remote5 -Action $Sta -Principal $STPrin -Trigger $trg
}

C:\xampp\htdocs\Scheduler_Web_v3.1\Remote_Schedule_PHP.ps1 -SCRIPT C:\xampp\htdocs\Scheduler_Web_v3.1\ScheduleTask_Server_PHP.ps1 -SERVERS_FILE C:\xampp\htdocs\Scheduler_Web_v3.1\servers.csv -Path C:\xampp\htdocs\Scheduler_Web_v3.1\test2.ps1 -TaskName "Remote_USER2" -Duration Once -Time "2021-07-18 6:35" -User "Guest"