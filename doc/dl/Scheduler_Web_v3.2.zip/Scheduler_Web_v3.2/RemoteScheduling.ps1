﻿$act = New-ScheduledTaskAction -Execute powershell.exe -Argument ..\..\xampp\htdocs\Scheduler\test.ps1
$trg= New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2)
$sSet = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 1)

Register-ScheduledTask -TaskName "task03" -Action $act -Trigger $trg -Settings $sSet -Force -RunLevel Highest

############################################################################################
Invoke-Command -ComputerName localhost -FilePath ..\..\xampp\htdocs\Scheduler\test2.ps1 -uName "abc" -pw "123"

Invoke-Command -ComputerName localhost -ScriptBlock { 
    C:\xampp\htdocs\Scheduler\test2.ps1 -uName "abc" -pw "sadsadasd" 
}

###########################################################################################################
$SCRIPT="C:\SCRIPTS\daily_script.bat"

$REMOTE_FILE=$SCRIPT -replace ":","$"
$SERVERS=Get-Content $SERVERS_FILE

Foreach ($SERVER in $SERVERS)
{
	If(Test-WSMan -ComputerName $SERVER -EA 0)
	{
        "Configuring the task on server $SERVER..."
        Copy-Item -Path "$SCRIPT" -Destination "\\$SERVER\$REMOTE_FILE"
		Invoke-Command -ComputerName $SERVER -FilePath ".\SCHEDULED_TASK.ps1"
	}
	Else 
	{
		"$SERVER is not available"
	}
}