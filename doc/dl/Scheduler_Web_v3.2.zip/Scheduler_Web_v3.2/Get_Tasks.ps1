﻿Get-ScheduledTaskInfo -TaskPath (Get-ScheduledTask -TaskName "New_Remote1").TaskPath


Get-ScheduledTaskInfo -TaskName "New_Remote1"

Get-ScheduledTask -TaskName "New_Remote1" | Get-ScheduledTaskInfo | Export-Csv -Path .\Desktop\tasks.csv -NoTypeInformation

$cimSess = New-CimSession -ComputerName 18.221.58.39 -Credential (Get-Credential -Message "Enter PW" -UserName Administrator)


Get-ScheduledTask -CimSession $cimSess -TaskName New_Remote1 | Get-ScheduledTaskInfo