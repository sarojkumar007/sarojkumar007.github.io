﻿Param(
    [String]$ServerFile
)

if(Test-Path $ServerFile)
{
    $servers = Import-Csv $ServerFile

}
foreach($server in $servers){
    if(Test-Connection $server.ip -Count 1 -Quiet)
    {
        Write-Host "$($server.ip) $($server.username) $($server.password)"
    }
}