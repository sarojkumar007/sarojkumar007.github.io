#[String]$LogFile,
Param(
    [String]$SCRIPT,
    [String]$SERVERS_FILE,
    [Parameter(Mandatory=$true)][string]$Path,
    [Parameter(Mandatory=$true)][string]$TaskName,
    [Parameter(Mandatory=$true)][ValidateSet("Once","Daily","Weekly","Monthly")][String]$Duration,
    [String]$Interval,
    [String]$WeekDays,
    [Parameter(Mandatory=$true)][String]$Time,
    [ValidateSet("Indefinitely","15 Minutes","30 Minutes","1 Hour","12 Hours","1 Day")][String]$RecurEvery,
    [ValidateSet("5 Minutes","10 Minutes","15 Minutes","30 Minutes","1 Hour")][String]$RecurInterval
)

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

########################################################
$ModuleFileName = Split-Path "$SCRIPT" -Leaf
$ScriptFileName = Split-Path "$Path" -Leaf
$SERVERS = import-Csv $SERVERS_FILE

Foreach ($SERVER in $SERVERS)
{
    $IP = $SERVER.ip
    $UN = $SERVER.username
    $PW = $SERVER.password

    If((Test-Connection $IP -Count 1 -Quiet) -and (Test-WSMan -ComputerName $IP -EA 0))
    {

        $ModulePath = "\\$($IP)\c$\TaskScheduler\$ModuleFileName"
        $ScriptPath = "\\$($IP)\c$\TaskScheduler\$ScriptFileName"
        
        if($UN){
            $PWord = ConvertTo-SecureString -String $PW -AsPlainText -Force
            $Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UN, $PWord
            $sess = New-PSSession -ComputerName $IP -Credential $Credential
        }
        "Configuring the task on IP $IP..."
        if((Test-Path $ModulePath) -and (Test-Path $ScriptPath)){}
        else{
            if($UN){
                Invoke-Command -Session $sess -ScriptBlock {
                    New-Item -Path "C:\TaskScheduler" -ItemType 'Directory' -Force
                    Copy-Item -Path "$using:SCRIPT" -Destination "C:\TaskScheduler\$using:ModuleFileName" -Force
                    Copy-Item -Path "$using:Path" -Destination "C:\TaskScheduler\$using:ScriptFileName" -Force
                }
                $Path = "C:\TaskScheduler\$ScriptFileName"
                $ModulePath = "C:\TaskScheduler\$ModuleFileName"
            }else{
                New-Item -Path "\\$($IP)\c$\TaskScheduler" -ItemType 'Directory' -Force
                Copy-Item -Path "$SCRIPT" -Destination $ModulePath -Force
                Copy-Item -Path "$Path" -Destination $ScriptPath -Force
                $Path = $ScriptPath
            }
        }
        #########################
        #Invoke-Command -ComputerName $IP -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$Time,$WeekDays,$RecurEvery,$RecurInterval)
        
        switch ($Duration)
        {
            'Once' {
                if($UN){
                    Invoke-Command -Session $sess -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,"DUMP",$Time,"DUMP","Indefinitely")
                }else{
                    Invoke-Command -ComputerName $IP -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,"DUMP",$Time,"DUMP","Indefinitely")
                }
                break;
             }
            'Daily'{
                if($UN){
                    Invoke-Command -Session $sess -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$Time,"DUMP",$RecurEvery,$RecurInterval)
                }else{
                    Invoke-Command -ComputerName $IP -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$Time,"DUMP",$RecurEvery,$RecurInterval)
                }
                break;
             }
            'Weekly'{
                if($UN){
                    Invoke-Command -Session $sess -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$Time,$WeekDays)
                }else{
                    Invoke-Command -ComputerName $IP -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$Time,$WeekDays)
                }
                break;
             }
            'Monthly'{break;}
            Default {break;}
        }

        Remove-PSSession -Session $sess
        #########################
        # WRITE TO CSV HERE
    }
    Else 
    {
        write-host "$IP is not available"
    }
    
}