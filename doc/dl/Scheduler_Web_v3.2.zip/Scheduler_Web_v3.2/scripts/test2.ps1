Param(
[String]$one,
[String]$two
)

$uName = $one
$pw = $two

write-host  $uName
write-host  $pw
start-sleep -seconds 10