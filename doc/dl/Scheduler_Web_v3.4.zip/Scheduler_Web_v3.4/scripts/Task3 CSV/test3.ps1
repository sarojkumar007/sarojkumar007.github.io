if(Test-Path $PSScriptRoot+"\servers.csv")
{
    $servers = Import-Csv ($PSScriptRoot+"\servers.csv")
    foreach ($item in $servers)
    {
        if(Test-Connection ($item.ip) -Count 1 -Quiet){
            Write-Host $item.ip " is pingable."
        }
        Start-Sleep -Seconds 2
    }
}
else{
    $servers = Get-Content ($PSScriptRoot+"\servers.txt")
    foreach ($item in $servers)
    {
        if(Test-Connection ($item) -Count 1 -Quiet){
            Write-Host $item " is pingable."
        }
        Start-Sleep -Seconds 2
    }
}

Start-Sleep 10