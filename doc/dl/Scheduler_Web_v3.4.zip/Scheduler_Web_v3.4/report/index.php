<?php
    include('../_config.php');

    $db = new DBConnect\CRUD("localhost","root","","scheduler");
    $table = "report";
    $colArr = array('*');
    $condition = "";

    $res = $db->FETCH_DATA($table,$colArr,$condition,1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduler Report</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../datatables/css/jquery.dataTables.min.css">
    <style>
        .table_report tr th,
        .table_report tr td{
            text-align:center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-light shadow bg-light">
        <a class="navbar-brand d-flex align-items-center font-weight-bold" href="#">
            <i data-feather="file-text" class="font-weight-bold"></i>
            &nbsp;Scheduler Report
        </a>
    </nav>
    <div class="container py-3">
        <div class="jumbotron bg-light d-flex align-items-center justify-content-center p-3">
            <h3>Scheduled Task Report</h3>
        </div>
        <table id="reportTable" class="table table-striped table_report">
            <thead>
                <tr>
                    <th>Sl. No</th>
                    <th>TaskName</th>
                    <th>Status</th>
                    <th>Author</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                function getBadge($s){
                    switch ($s) {
                        case 'Ready':
                            return '<span class="badge badge-success">'.$s.'</span>';
                            break;
                        case 'Running':
                            return '<span class="badge badge-warning">'.$s.'</span>';
                            break;
                        case 'Stopped':
                            return '<span class="badge badge-danger">'.$s.'</span>';
                            break;
                        default:
                            return '<span class="badge badge-light">'.$s.'</span>';
                            break;
                    }
                }

                    for ($i=0; $i < count($res); $i++) {
                        
                        $row = $res[$i];

                        echo '<tr>
                            <td>'.($i+1).'</td>
                            <td>'.$row['TaskName'].'</td>
                            <td>'.getBadge($row['Status']).'</td>
                            <td>'.$row['Author'].'</td>
                            <td>'.$row['Created'].'</td>
                            <td>
                                <span class="text-danger" title="Remove Task">
                                    <i data-feather="trash-2" class="font-weight-bold"></i>
                                </span>
                            </td>
                        </tr>';
                    }
                    
                ?>
            </tbody>
        </table>
    </div>

    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/feather.min.js"></script>
    <script src="../datatables/js/jquery.dataTables.min.js"></script>
    <script>
        feather.replace();
        $(document).ready(function() {
			$('#reportTable').DataTable();
		});
    </script>
</body>
</html>