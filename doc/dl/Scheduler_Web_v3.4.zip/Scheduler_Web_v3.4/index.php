<?php
    session_start();

    $url = parse_url("http://localhost".$_SERVER['REQUEST_URI'], PHP_URL_PATH);

    $activeTab = 'once';
    if(isset($_GET['tab'])){
        switch ($_GET['tab']) {
            case 'once':
            case 'Once':
                $activeTab = 'once';
                break;
            case 'daily':
            case 'Daily':
                $activeTab = 'daily';
                break;
            case 'weekly':
            case 'Weekly':
                $activeTab = 'weekly';
                break;
            case 'monthly':
            case 'Monthly':
                $activeTab = 'monthly';
                break;
            default:
                $activeTab = 'once';
                break;
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduler</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/jquery-ui-timepicker-addon.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Temp CSS */
        body{padding: 10px 40px;}
        .container{padding: 20px;}
        /* ------ */
    </style>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/feather.min.js"></script>
    <!-- <script src="js/jquery-1.12.4.js"></script> -->
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery-ui-timepicker-addon.js"></script>
</head>
<body>
    <!-- main code -->
    <nav class="navbar navbar-light bg-light">
        <a class="navbar-brand d-flex align-items-center font-weight-bold" href="#">
            <i data-feather="clipboard" class="font-weight-bold"></i>
            &nbsp;Scheduler
        </a>
        <div class="navbar-nav right">
            <a class="nav-link text-primary" href="<?php echo $url."report/"; ?>">Report</a>
        </div>
    </nav>
    <div class="container">
        <ul class="nav nav-tabs" id="schedulerTab" role="tablist">
            <li class="nav-item">
                <a class="tab_link nav-link <?php echo ((isset($activeTab) and ($activeTab == 'once')) ? 'active': ''); ?>" id="once-tab" data-toggle="tab" href="#once" data-tab="once" role="tab" aria-controls="once" aria-selected="true">Once Task</a>
            </li>
            <li class="nav-item">
                <a class="tab_link nav-link <?php echo ((isset($activeTab) and ($activeTab == 'daily')) ? 'active': ''); ?>" id="daily-tab" data-toggle="tab" href="#daily" data-tab="daily" role="tab" aria-controls="daily" aria-selected="false">Daily Task</a>
            </li>
            <li class="nav-item">
                <a class="tab_link nav-link <?php echo ((isset($activeTab) and ($activeTab == 'weekly')) ? 'active': ''); ?>" id="weekly-tab" data-toggle="tab" href="#weekly" data-tab="weekly" role="tab" aria-controls="weekly" aria-selected="false">Weekly Task</a>
            </li>
            <!-- <li class="nav-item">
                <a class="tab_link nav-link <?php echo ((isset($activeTab) and ($activeTab == 'monthly')) ? 'active': ''); ?>" id="monthly-tab" data-toggle="tab" href="#monthly" data-tab="monthly" role="tab" aria-controls="monthly" aria-selected="false">Monthly Task</a>
            </li> -->
        </ul>
        <div class="tab-content" id="schedulerTabContent">
            <div class="tab-pane fade <?php echo ((isset($activeTab) and ($activeTab == 'once')) ? 'show active': ''); ?>" id="once" role="tabpanel" aria-labelledby="once-tab">
                <?php include('_tab_once.php'); ?>
            </div>
            <div class="tab-pane fade <?php echo ((isset($activeTab) and ($activeTab == 'daily')) ? 'show active': ''); ?>" id="daily" role="tabpanel" aria-labelledby="daily-tab">
                <?php include('_tab_daily.php'); ?>
            </div>
            <div class="tab-pane fade <?php echo ((isset($activeTab) and ($activeTab == 'weekly')) ? 'show active': ''); ?>" id="weekly" role="tabpanel" aria-labelledby="weekly-tab">
                <?php include('_tab_weekly.php'); ?>
            </div>
            <!-- <div class="tab-pane fade <?php echo ((isset($activeTab) and ($activeTab == 'monthly')) ? 'show active': ''); ?>" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                <p>To be updated ...</p>
            </div> -->
        </div>
    </div>

    <script>
        feather.replace();
        // https://getbootstrap.com/docs/4.0/components/navs/#javascript-behavior

        $(".tab_link").each(function(i,tab){
            $(tab).on('click',function(e){
                window.location.replace(window.location.origin+window.location.pathname+'?tab='+e.target.dataset.tab);
            });
        });

        $("#once_date").datepicker();
        $("#once_time").timepicker();
        $("#daily_date").datepicker();
        $("#daily_time").timepicker();
        $("#weekly_date").datepicker();
        $("#weekly_time").timepicker();
    </script>
</body>
</html>