﻿function Show-DailyScheduler
{
    [CmdletBinding()]
    [Alias()]
    Param
    (
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)][String]$FilePath,
        [Parameter(Mandatory=$true,Position=1)][String]$TaskName,
        [String]$SettingEvery,
        [int]$SettingInterval,
        [Parameter(Mandatory=$true,Position=2)][String]$MainModulePath
    )
    Begin
    {
        Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
        Import-Module $MainModulePath -wa Ignore
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.Application]::EnableVisualStyles()
        
        # Global Changes
        $fontFamily = "Microsoft Sans Serif"
        $fontSize = 11
        $height = 30
        $initLine = 30
    }
    Process
    {
        $DailyForm                        = New-Object system.Windows.Forms.Form
        $DailyForm.ClientSize             = New-Object System.Drawing.Point(960,320)
        $DailyForm.text                   = "Schedule a Task"
        $DailyForm.TopMost                = $false
        
        $DailyFileLabel                   = New-Object system.Windows.Forms.Label
        $DailyFileLabel.text              = "Script Path"
        $DailyFileLabel.AutoSize          = $true
        $DailyFileLabel.width             = 60
        $DailyFileLabel.height            = $height
        $DailyFileLabel.location          = New-Object System.Drawing.Point(20,$initLine)
        $DailyFileLabel.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $DailyFilePath                       = New-Object system.Windows.Forms.Label
        $DailyFilePath.text                  = $FilePath
        $DailyFilePath.AutoSize              = $true
        $DailyFilePath.width                 = 60
        $DailyFilePath.height                = $height
        $DailyFilePath.location              = New-Object System.Drawing.Point(190,$initLine)
        $DailyFilePath.Font                  = New-Object System.Drawing.Font($fontFamily,($fontSize - 1))

        $DailyLabel                       = New-Object system.Windows.Forms.Label
        $DailyLabel.text                  = "Select DateTime"
        $DailyLabel.AutoSize              = $true
        $DailyLabel.width                 = 25
        $DailyLabel.height                = $height
        $DailyLabel.location              = New-Object System.Drawing.Point(20,($initLine + $height + 8))
        $DailyLabel.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $datePicker                      = New-Object System.Windows.Forms.DateTimePicker
        $datePicker.Width = 240
        $datePicker.Height = 32
        $datePicker.Format               = [windows.forms.datetimepickerFormat]::custom
        $datePicker.CustomFormat         = “MM/dd/yyyy HH:mm”
        $datePicker.Location             = New-Object System.Drawing.Point(240,($initLine + $height + 8))
        $datePicker.Font                 = New-Object System.Drawing.Font($fontFamily,($fontSize+1))

        # ------------------------------------- Recur Every ----------------------------------------------------------

        $DailyInterval                       = New-Object system.Windows.Forms.Label
        $DailyInterval.text                  = "Recur every "
        $DailyInterval.AutoSize              = $true
        $DailyInterval.width                 = 25
        $DailyInterval.height                = $height
        $DailyInterval.location              = New-Object System.Drawing.Point(20,($initLine + (2*$height) + 16))
        $DailyInterval.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)

        $DailyRecur                        = New-Object system.Windows.Forms.TextBox
        $DailyRecur.multiline              = $false
        $DailyRecur.width                  = 48
        $DailyRecur.height                 = $height
        $DailyRecur.Text                   = 1
        $DailyRecur.location               = New-Object System.Drawing.Point(240,($initLine + (2*$height) + 16))
        $DailyRecur.Font                   = New-Object System.Drawing.Font($fontFamily,($fontSize+4))

        $DailyInterval2                       = New-Object system.Windows.Forms.Label
        $DailyInterval2.text                  = "Day(s)"
        $DailyInterval2.AutoSize              = $true
        $DailyInterval2.height                = $height
        $DailyInterval2.location              = New-Object System.Drawing.Point(308,($initLine + (2*$height) + 16))
        $DailyInterval2.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)

        # ----------------------------------- Repeat Task Interval ----------------------------------------------------------------

        $DailyRepeatInterval                    = New-Object system.Windows.Forms.Label
        $DailyRepeatInterval.text               = "Repeat task every: "
        $DailyRepeatInterval.AutoSize           = $true
        $DailyRepeatInterval.width              = 25
        $DailyRepeatInterval.height             = $height
        $DailyRepeatInterval.location           = New-Object System.Drawing.Point(20,($initLine + (3*$height) + 24))
        $DailyRepeatInterval.Font               = New-Object System.Drawing.Font($fontFamily,$fontSize)

        $DailyRIntComboBox                 = New-Object system.Windows.Forms.ComboBox
        $DailyRIntComboBox.text            = "Select"
        $DailyRIntComboBox.width           = 160
        $DailyRIntComboBox.height          = $height
        @("5 Minutes","10 Minutes","15 Minutes","30 Minutes","1 Hour") | ForEach-Object {[void] $DailyRIntComboBox.Items.Add($_)}
        $DailyRIntComboBox.location        = New-Object System.Drawing.Point(240,($initLine + (3*$height) + 24))
        $DailyRIntComboBox.Font            = New-Object System.Drawing.Font($fontFamily,($fontSize+4))

         # ----------------------------------- Repeat Task Duration ----------------------------------------------------------------

        $DailyRepeatEvery                    = New-Object system.Windows.Forms.Label
        $DailyRepeatEvery.text               = "for a duration of: "
        $DailyRepeatEvery.AutoSize           = $true
        $DailyRepeatEvery.width              = 25
        $DailyRepeatEvery.height             = $height
        $DailyRepeatEvery.location           = New-Object System.Drawing.Point(480,($initLine + (3*$height) + 24))
        $DailyRepeatEvery.Font               = New-Object System.Drawing.Font($fontFamily,$fontSize)

        $DailyREveryComboBox                 = New-Object system.Windows.Forms.ComboBox
        $DailyREveryComboBox.text            = "Select"
        $DailyREveryComboBox.width           = 160
        $DailyREveryComboBox.height          = $height
        @("Indefinitely","15 Minutes","30 Minutes","1 Hour","12 Hours","1 Day") | ForEach-Object {[void] $DailyREveryComboBox.Items.Add($_)}
        $DailyREveryComboBox.location        = New-Object System.Drawing.Point(700,($initLine + (3*$height) + 24))
        $DailyREveryComboBox.Font            = New-Object System.Drawing.Font($fontFamily,($fontSize+4))

        # --------------------------------- Schedule ------------------------------------------------------------------

        $DailySubmit                      = New-Object system.Windows.Forms.Button
        $DailySubmit.text                 = "Schedule"
        $DailySubmit.width                = 120
        $DailySubmit.height               = 30
        $DailySubmit.Cursor                 = [System.Windows.Forms.Cursors]::Hand
        $DailySubmit.location             = New-Object System.Drawing.Point(500,270)
        $DailySubmit.Font                 = New-Object System.Drawing.Font($fontFamily,$fontSize)

        # ------------------------------------- Combine All ------------------------------------------------------------------

        $DailyForm.controls.AddRange(@($DailyFileLabel,$DailyFilePath,$DailyLabel,$datePicker,$DailyInterval,$DailyRecur,$DailyInterval2,$DailyRepeatInterval,$DailyRIntComboBox,$DailyRepeatEvery,$DailyREveryComboBox,$DailySubmit))
        $DailySubmit.Add_Click({ ScheduleDailyTask })

        # ------------------------------------------- LOGIC -----------------------------------------------------------------

        function ScheduleDailyTask {
            if(([int]($DailyRecur.Text)) -ge 1){
                try{
                    if($SettingEvery -and $SettingInterval){
                        $result = Schedule-Task -Path $FilePath -TaskName $TaskName -Duration Daily -Interval ([int]($DailyRecur.Text)) -RecurEvery ($DailyREveryComboBox.SelectedItem) -RecurInterval ($DailyRIntComboBox.SelectedItem) -Time (Get-Date -Date $datePicker.Text) -SettingEvery $SettingEvery -SettingInterval $SettingInterval
                    }
                    else{
                        $result = Schedule-Task -Path $FilePath -TaskName $TaskName -Duration Daily -Interval ([int]($DailyRecur.Text)) -RecurEvery ($DailyREveryComboBox.SelectedItem) -RecurInterval ($DailyRIntComboBox.SelectedItem) -Time (Get-Date -Date $datePicker.Text)
                    }
                    if(($result -split ":")[0] -eq 'Error'){throw $result}
                    Write-Host "Task, $($TaskName) scheduled successfully" -fore Green
                    $res = [System.Windows.MessageBox]:: Show("Task, $($TaskName) Scheduled successfully!",'Task Scheduled','OK','Info')
                    if($res -eq "OK"){
                        $DailyForm.Close()
                    }
                }
                catch{
                    $res = [System.Windows.MessageBox]:: Show($_.Exception.Message,'Task Scheduling Failed','OK','Error')
                    if($res -eq 'OK'){
                        $DailyForm.Close()
                    }
                }
            }
            else{
                [System.Windows.MessageBox]:: Show('Recur Days cannot be less than 1','Task Scheduling Failed','OK','Warning')
            }
        }
        # Show Dialog
        [void]$DailyForm.ShowDialog()
    }
}