﻿function Schedule-Task
{
    [CmdletBinding()]
    [Alias('schtsk')]
    
    Param
    (
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)][string]$Path,
        [Parameter(Mandatory=$true)][string]$TaskName,
        [Parameter(Mandatory=$true)][ValidateSet("Once","Daily","Weekly","Monthly")][String]$Duration,
        [int]$Interval,
        [ValidateSet("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")][String[]]$WeekDays,
        [validateSet("January","February","March","April","May","June","July","August","September","October","November","December")][String[]]$Months,
        [validateSet(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31)][int]$Day,
        [Parameter(Mandatory=$true)][DateTime]$Time,
        [ValidateSet("FIRST","SECOND","THIRD","FOURTH","LAST")][String]$Modifier,
        [ValidateSet("Indefinitely","15 Minutes","30 Minutes","1 Hour","12 Hours","1 Day")][String]$RecurEvery,
        [ValidateSet("5 Minutes","10 Minutes","15 Minutes","30 Minutes","1 Hour")][String]$RecurInterval,
        [ValidateSet("1 Minute","5 Minutes","10 Minutes","30 Minutes","1 Hour","2 Hours")][String]$SettingEvery,
        [int]$SettingInterval
    )
   
    Process
    {
    Write-Warning "Run this script with admin access."
    try{
        if((Test-Path $Path) -and ([System.IO.Path]::GetExtension($Path) -eq '.ps1'))
        {
            $psPath = (Resolve-Path -Path $Path).Path
            $p = $psPath.Split('\')
            $fileName = $p[-1].Split('.')
            $fileName = [String]::Join("",$fileName[0..($fileName.Length -2)])
            $p = [String]::Join("\",$p[0..($p.Length - 2)])
            $batPath = "$($p)\$($fileName).bat"

            try{
                Set-Content -Value "Powershell.exe -Executionpolicy Unrestricted -File `"$psPath`"" -Path $batPath
            }catch{return "Error: creating batch file"}

            ## ---------------------------- CREATE TASK ACTION ---------------------------------------------------------
            
            $task= New-ScheduledTaskAction -Execute $batPath
            $STSet = $null
            if($SettingEvery){
                $sEvery = ''
                switch($SettingEvery){
                    "1 Minute"{$sEvery = New-TimeSpan -Minutes 1; break;}
                    "5 Minutes"{$sEvery = New-TimeSpan -Minutes 5; break;}
                    "10 Minutes"{$sEvery = New-TimeSpan -Minutes 10; break;}
                    "30 Minutes"{$sEvery = New-TimeSpan -Minutes 30; break;}
                    "1 Hour"{$sEvery = New-TimeSpan -Hours 1; break;}
                    "2 Hours"{$sEvery = New-TimeSpan -Hours 2; break;}
                    default{break;}
                }
                $STSet = New-ScheduledTaskSettingsSet  -RunOnlyIfNetworkAvailable -DontStopIfGoingOnBatteries -RestartCount:$SettingInterval -RestartInterval $sEvery -StartWhenAvailable
            }else{
                $STSet = New-ScheduledTaskSettingsSet  -RunOnlyIfNetworkAvailable -DontStopIfGoingOnBatteries -StartWhenAvailable            
            }
            $STSet.DisallowStartIfOnBatteries =$false

            if($Duration){
                switch($Duration){
                # ONCE TASK
                    'Once'{
                        $trg= New-ScheduledTaskTrigger -Once -At $Time
                        try{
                            Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Trigger $trg -Settings $STSet -RunLevel Highest -ea Stop
                        }
                        catch{return "Error: $($_.Exception.Message)"}
                    }
                # DAILT TASK
                    'Daily'{
                        $trg = New-ScheduledTaskTrigger -Daily -DaysInterval $Interval -At $Time
                        if($RecurEvery -and $RecurInterval){
                            $rInterval = ''
                            switch($RecurInterval){
                                "5 Minutes"{$rInterval = New-TimeSpan -Minutes 5;break;}
                                "10 Minutes"{$rInterval = New-TimeSpan -Minutes 10; break;}
                                "15 Minutes"{$rInterval = New-TimeSpan -Minutes 15; break;}
                                "30 Minutes"{$rInterval = New-TimeSpan -Minutes 30; break;}
                                "1 Hour"{$rInterval = New-TimeSpan -Hours 1; break;}
                                default{break;}
                            }
                            $rEvery = ''
                            switch($RecurEvery){
                                "15 Minutes"{$rEvery = New-TimeSpan -Minutes 15;break;}
                                "30 Minutes"{$rEvery = New-TimeSpan -Minutes 30;break;}
                                "1 Hour"{$rEvery = New-TimeSpan -Hours 1;break;}
                                "12 Hours"{$rEvery = New-TimeSpan -Hours 12;break;}
                                "1 Day"{$rEvery = New-TimeSpan -Days 1;break;}
                                default{break;}
                            }
                            if($rEvery){
                                $trg.Repetition = (New-ScheduledTaskTrigger -Once -At $Time -RepetitionDuration $rEvery -RepetitionInterval $rInterval).Repetition
                            } 
                            else{
                                $trg.Repetition = (New-ScheduledTaskTrigger -Once -At $Time -RepetitionInterval $rInterval).Repetition
                            }
                        }
                        try{                        
                            Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Trigger $trg -Settings $STSet -RunLevel Highest -ea Stop
                        }
                        catch{return "Error: $($_.Exception.Message)"}
                    }
                # WEEKLY TASK
                    'Weekly'{
                        try{
                            $trg= New-ScheduledTaskTrigger -Weekly -At $Time -DaysOfWeek $WeekDays -WeeksInterval $Interval
                            Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Trigger $trg -Settings $STSet -RunLevel Highest -ea Stop
                        }
                        catch{return "Error: $($_.Exception.Message)"}
                    }
                # MONTHLY TASK
                    'Monthly'{
                        $mon = $Months | % {$_.Substring(0,3).ToUpper()}
                        $mon = [String]::Join(",",$mon)
                        $taskParams = ''
                        if($Modifier){
                            if($WeekDays -and $Months){
                            $wds = $WeekDays | % {$_.Substring(0,3).ToUpper()}
                            $wds = [String]::Join(" ",$wds)
                            $taskParams = @("/Create",
                                        "/TN", $TaskName, 
                                        "/SC", "monthly",
                                        "/M", $mon,
                                        "/MO",$Modifier,
                                        "/D",$wds,
                                        "/ST", $Time.ToString('HH:mm'), 
                                        "/TR", $batPath,
                                        "/RL","HIGHEST",
                                        "/F");
                            }
                            else{
                                Write-Host "Please provide weekdays for modifier" -fore Cyan
                                return "Error: Please provide weekdays for modifier"
                            }
                        }
                        else{
                            if($Months -and $Day){
                                $taskParams = @("/Create",
                                    "/TN", $TaskName, 
                                    "/SC", "monthly",
                                    "/M", $mon,
                                    "/D",$Day,
                                    "/ST", $Time.ToString('HH:mm'), 
                                    "/TR", $batPath,
                                    "/RL","HIGHEST",
                                    "/F");
                            }
                            else{
                                Write-Host "Please provide Months and Days" -fore Cyan
                                return "Error: Please provide Months and Days"
                            }
                        }

                        try{
                            schtasks.exe @taskParams
                        }catch{
                            Write-Host "Error scheduling monthly task" -fore Red
                            return "Error: $($_.Exception.Message)"
                        }
                    } # monthly case end
                } # switch end
            }
        } # if path exist check
        else
        {
            Write-Host "$Path not valid Path or Provide a ps1 file." -fore Yellow
            return "Error: $Path not valid Path or Provide a ps1 file."
        }
       
    }catch{
        Write-Host $_.Exception.Message
        return "Error: $($_.Exception.Message)"
    }
  }
}