<?php

    $MainModule = __DIR__."\ScheduleTask_Server_PHP.ps1";
    $PingServerModulePath = __DIR__."\Ping_Servers_PHP.ps1";
    $RemoteServerModule = __DIR__."\Remote_Schedule_PHP.ps1";
    $Pingables = __DIR__."\servers\pingable.csv";

    if(isset($_POST['daily_uploadScriptFile'])){
        $f = $_FILES['daily_scriptFile'];
        // $sz = (int)$f['size'];
        // $sz = number_format($sz / 1024,2);

        $uploadPath = 'scripts\\';
        $ext = pathinfo($_FILES['daily_scriptFile']['name'],PATHINFO_EXTENSION);
        $filename = $_FILES['daily_scriptFile']['name'];
        $scriptPath = $uploadPath.$filename;			
        
        $allowed_csv_ext=array("ps1");
        if ( !in_array($ext, $allowed_csv_ext)) {
            echo '<script>alert("Please upload file in .ps1 format");</script>';
            header("Refresh:1");
        }else{
            if(file_exists($scriptPath)){
                // echo '<script>alert("File with this name already exists");</script>';
            }else{
                move_uploaded_file($_FILES['daily_scriptFile']['tmp_name'], $scriptPath);
            }
            $_SESSION['daily_script_file'] = __DIR__.'\\'.$scriptPath;
        }
    }

    if(isset($_POST['daily_uploadServerFile'])){
        $serverFile = $_FILES['daily_serverFile'];

        $uploadPath = 'servers\\';
        $ext = pathinfo($_FILES['daily_serverFile']['name'],PATHINFO_EXTENSION);
        $filename = $_FILES['daily_serverFile']['name'];
        $serverPath = $uploadPath.$filename;			
        
        $allowed_csv_ext=array("csv");
        if ( !in_array($ext, $allowed_csv_ext)) {		
            echo '<script>alert("Please upload file in .csv format");</script>';
            header("Refresh:1");
        }else{
            if(file_exists($serverPath)){
                // echo '<script>alert("File with this name already exists");</script>';
            }else{
                move_uploaded_file($_FILES['daily_serverFile']['tmp_name'], $serverPath);
            }
            $_SESSION['daily_server_file'] = __DIR__.'\\'.$serverPath;
        }
    }

    if(isset($_POST['scheduleDaily'])){
        $scriptAbsPath = realpath($_POST['daily_scriptPathDisplay']);
        $serverAbsPath = realpath($_POST['daily_serverPathDisplay']);

        if($serverAbsPath){
            $pingCommand = 'powershell.exe -File "'.$PingServerModulePath.'" -ServerFile "'.$serverAbsPath.'"';
            exec($pingCommand, $pingOutput,$err);
            if($err){echo "ERROR";}
            if($pingOutput){
                if (file_exists('servers/pingable.csv')) {
                    unlink('servers/pingable.csv');
                }
                
                $arr = array();
                $handle = fopen("servers/pingable.csv", "w");
                
                $arr[] = "ip,username,password";

                foreach($pingOutput as $server) {
                    $data = explode(" ",$server);
                    if(count($data) == 1){
                        $arr[] = $data[0].",,";
                    }
                    else{
                        $arr[] = implode(",",$data);
                    }                    
                }
                
                $new_arr = implode("\n", $arr);
                fwrite($handle, print_r($new_arr, true));
                fclose($handle);
            
            }
        }

        if($scriptAbsPath){
            $daily_taskName = $_POST['daily_taskName'];
            $daily_date = $_POST['daily_date'];
            $daily_time = $_POST['daily_time'];
            $daily_interval = $_POST['daily_interval'];
            $daily_repeatEvery = $_POST['daily_repeatEvery'];
            $daily_repeatInterval = $_POST['daily_repeatInterval'];

            $command = 'powershell.exe -File "'.$RemoteServerModule.'" -SCRIPT "'.$MainModule.'" -SERVERS_FILE "'.$Pingables.'" -Path "'.$scriptAbsPath.'" -TaskName "'.$daily_taskName.'" -Duration Daily -Interval "'.$daily_interval.'" -Time "'.$daily_date.' '.$daily_time.'" -RecurEvery "'.$daily_repeatEvery.'" -RecurInterval "'.$daily_repeatInterval.'"';

            exec($command, $output, $err);
            if($err){
                $D_MSG = '<div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="row" style="align-items: center;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                        <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                        <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                    </svg>
                    <strong>Failed!</strong>&nbsp;Task Failed, Try again.
                </div>
              </div>';
            }else{
                $D_MSG = '<div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="row" style="align-items: center;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                        <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                        <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                    </svg>
                    <strong>Success!</strong>&nbsp;Daily Task Scheduled Successfully.
                </div>
              </div>';
            }
        }

        if(isset($_SESSION['daily_script_file'])){
            $_SESSION['daily_script_file'] = '';
        }
        if(isset($_SESSION['daily_server_file'])){
            $_SESSION['daily_server_file'] = '';
        }
    }
?>

<!-- modal for script file -->
<div class="modal fade" id="daily_scriptFileModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form action="?tab=daily" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <p><strong><span class="lead text-dange">*</span> Upload Daily Script File</strong></p>
                <div class="form-group">
                    <input type="file" name="daily_scriptFile" id="daily_scriptFile" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="daily_uploadScriptFile" class="btn btn-info">Upload</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- modal for server file -->
<div class="modal fade" id="daily_serverFileModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form action="?tab=daily" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <p><strong>Upload Server File</strong></p>
                <div class="form-group">
                    <input type="file" name="daily_serverFile" id="daily_serverFile">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="daily_uploadServerFile" class="btn btn-info">Upload</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>


<!-- MAIN CODE -->
<div class="container">
    <?php if(isset($D_MSG)){echo '<div class="message_box">'.$D_MSG.'</div>';}?>
    <div class="task_title">
        <span style="margin-right: 10px;">
            <i data-feather="clock" class="font-weight-bold"></i>
        </span>
        <h2 class="lead font-weight-bold">Schedule a Task for Daily</h2>
    </div>      
    <hr>
    <form action="?tab=daily" method="POST">
    <p><strong class="lead text-danger">*</strong> Script Path</p>
    <p class="text-small">Provide absolute path to script or browse to upload file.</p>
    <div class="row form-group">
        <div class="col col-md-10">
            <input type="text" name="daily_scriptPathDisplay" id="daily_scriptPathDisplay" class="form-control" value="<?php if(isset($_SESSION['daily_script_file'])){echo $_SESSION['daily_script_file'];}?>" required>
        </div>
        <div class="col col-md-2">
            <a class="btn btn-light" data-toggle="modal" data-target="#daily_scriptFileModal">Browse</a>
        </div>
    </div>
    <p>Servers File</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="daily_serverPathDisplay" id="daily_serverPathDisplay" class="form-control" value="<?php if(isset($_SESSION['daily_server_file'])){echo $_SESSION['daily_server_file'];}?>">
        </div>
        <div class="col col-md-3">
            <a class="btn btn-light" data-toggle="modal" data-target="#daily_serverFileModal">Upload Server File</a>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-6 form-group">
            <p><strong class="lead text-danger">*</strong> Task Name</p>
            <input type="text" name="daily_taskName" id="daily_taskName" class="form-control" required />
        </div>
        <div class="col col-md-6 form-group">
            <p class=""><strong class="lead text-danger">*</strong> Select Date and Time (UTC +5:30):</p>
            <div class="row form-group pl-3">
                <input type="date" name="daily_date" id="daily_date" class="form-control col col-md-7" required>
                <input type="time" name="daily_time" id="daily_time" class="form-control col col-md-5" required>
            </div>
        </div>
    </div>
    <div class="row form-group">
        <p class="col col-md-3"><strong class="lead text-danger">*</strong> Recur Every:</p>
        <input type="number" name="daily_interval" id="daily_interval" min="1" value="1" class="col col-md-2 form-control" required>
        <p class="col col-md-3">Day(s)</p>
    </div>
    <p class="font-weight-bold">Advanced Settings</p>
    <hr>
    <div class="row form-group">
        <p class="col col-md-3">Repeat Task Every:</p>
        <select name="daily_repeatInterval" id="daily_repeatInterval" class="col col-md-3 form-control">
            <option value="5 Minutes">5 Minutes</option>
            <option value="10 Minutes">10 Minutes</option>
            <option value="15 Minutes">15 Minutes</option>
            <option value="30 Minutes">30 Minutes</option>
            <option value="1 Hour" selected>1 Hour</option>
        </select>
        <p class="col col-md-3">for a duration of:</p>
        <select name="daily_repeatEvery" id="daily_repeatEvery" class="form-control col col-md-3">
            <option value="Indefinitely">Indefinitely</option>
            <option value="15 Minutes">15 Minutes</option>
            <option value="30 Minutes">30 Minutes</option>
            <option value="1 Hour">1 Hour</option>
            <option value="12 Hours">12 Hours</option>
            <option value="1 Day" selected>1 Day</option>
        </select>
    </div>
    <div class="row" style="margin-top: 60px;">
        <button type="submit" name="scheduleDaily" class="btn btn-primary mr-3">Schedule</button>
        <button type="reset" class="btn btn-light">Cancel</button>
    </div>
    </form>
</div>