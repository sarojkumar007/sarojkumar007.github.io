﻿################################ SETTINGS ################################################################

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

## -------------------------- Global Changes --------------------------------------------------------------

$fontFamily = "Microsoft Sans Serif"
$fontSize = 11
$height = 30
$initLine = 30

$OnceDialogModule     = "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\SchedulerGUI_Once.psm1"
$DailyDialogModule    = "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\SchedulerGUI_Daily.psm1"
$WeeklyDialogModule   = "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\SchedulerGUI_Weekly.psm1"
$AccountDialogModule  = "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\SchedulerGUI_Account.psm1"
$MainModule           = "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\Schedule-Task.psm1"

## ----------------------------- Main FORM -------------------------------------------------------------------

$Schedule                        = New-Object System.Windows.Forms.Form
$Schedule.ClientSize             = New-Object System.Drawing.Point(720,480)
$Schedule.Text                   = "Schedule a Task"
$Schedule.StartPosition          = "CenterScreen"
$Schedule.TopMost                = $false

# ------------------------------ Script Path -------------------------------------------

$PathLabel                       = New-Object System.Windows.Forms.Label
$PathLabel.Text                  = "Script Path"
$PathLabel.AutoSize              = $true
$PathLabel.Height                = $height
$PathLabel.Location              = New-Object System.Drawing.Point(20,$initLine)
$PathLabel.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)

$Path                            = New-Object system.Windows.Forms.TextBox
$Path.multiline                  = $false
$Path.width                      = 360
$Path.height                     = $height
$Path.location                   = New-Object System.Drawing.Point(180,$initLine)
$Path.Font                       = New-Object System.Drawing.Font($fontFamily,($fontSize+2))

$Button1                         = New-Object system.Windows.Forms.Button
$Button1.text                    = "Browse"
$Button1.width                   = 140
$Button1.height                  = ($height + 8)
$Button1.Padding                 = 4
$Button1.Cursor                  = [System.Windows.Forms.Cursors]::Hand
$Button1.location                = New-Object System.Drawing.Point(560,($initLine - 4))
$Button1.Font                    = New-Object System.Drawing.Font($fontFamily,$fontSize)

$FileOpen = New-Object System.Windows.Forms.OpenFileDialog
$FileOpen.Filter = "PowerShell Scripts(*.ps1)|*.ps1"

# ------------------------------ Task Name ------------------------------------------------
$TaskNameLabel                   = New-Object system.Windows.Forms.Label
$TaskNameLabel.text              = "Task Name"
$TaskNameLabel.AutoSize          = $true
$TaskNameLabel.width             = 25
$TaskNameLabel.height            = $height
$TaskNameLabel.location          = New-Object System.Drawing.Point(20,($initLine + $height + 8))
$TaskNameLabel.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize)

$TextBox1                        = New-Object system.Windows.Forms.TextBox
$TextBox1.multiline              = $false
$TextBox1.width                  = 360
$TextBox1.height                 = $height
$TextBox1.location               = New-Object System.Drawing.Point(180,($initLine + $height + 8))
$TextBox1.Font                   = New-Object System.Drawing.Font($fontFamily,($fontSize+2))

# ------------------------------ Duration ----------------------------------------------------

$durationLabel                   = New-Object system.Windows.Forms.Label
$durationLabel.text              = "Duration"
$durationLabel.AutoSize          = $true
$durationLabel.width             = 25
$durationLabel.height            = 20
$durationLabel.location          = New-Object System.Drawing.Point(20,($initLine + (2*$height) + 16))
$durationLabel.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize)

$ComboBox1                       = New-Object system.Windows.Forms.ComboBox
$ComboBox1.text                  = "Once"
$ComboBox1.width                 = 125
$ComboBox1.height                = $height
@('Once','Daily','Weekly','Monthly') | ForEach-Object {[void] $ComboBox1.Items.Add($_)}
$ComboBox1.location              = New-Object System.Drawing.Point(180,($initLine + (2*$height) + 16))
$ComboBox1.Font                  = New-Object System.Drawing.Font($fontFamily,($fontSize+4))
$ComboBox1.Padding               = 30
#$ComboBox1.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList

## ------------------------------ Settings ---------------------------------------------------------

$settingsLabel                       = New-Object system.Windows.Forms.CheckBox
$settingsLabel.text                  = "Settings:"
$settingsLabel.AutoSize              = $false
$settingsLabel.width                 = 160
$settingsLabel.height                = $height
$settingsLabel.location              = New-Object System.Drawing.Point(20,($initLine + (3*$height) + 24))
$settingsLabel.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize,[System.Drawing.FontStyle]::Bold)
<#
$settingsLabel                   = New-Object system.Windows.Forms.Label
$settingsLabel.text              = "Settings:"
$settingsLabel.AutoSize          = $true
$settingsLabel.height            = $height
$settingsLabel.location          = New-Object System.Drawing.Point(20,($initLine + (3*$height) + 24))
$settingsLabel.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize,[System.Drawing.FontStyle]::Bold)
#>
$settingsLabel1                  = New-Object system.Windows.Forms.Label
$settingsLabel1.text             = "If the task fails, restart every: "
$settingsLabel1.AutoSize         = $true
$settingsLabel1.height           = $height
$settingsLabel1.location         = New-Object System.Drawing.Point(20,($initLine + (4*$height) + 32))
$settingsLabel1.Font             = New-Object System.Drawing.Font($fontFamily,$fontSize)

$ComboBox2                       = New-Object system.Windows.Forms.ComboBox
$ComboBox2.text                  = "5 Minutes"
$ComboBox2.width                 = 125
$ComboBox2.height                = $height
@('1 Minute','5 Minutes','10 Minutes','30 Minutes','1 Hour','2 Hours') | ForEach-Object {[void] $ComboBox2.Items.Add($_)}
$ComboBox2.location              = New-Object System.Drawing.Point(360,($initLine + (4*$height) + 32))
$ComboBox2.Font                  = New-Object System.Drawing.Font($fontFamily,($fontSize+4))
$ComboBox2.Padding               = 30
$ComboBox2.Enabled               = $false

$settingsLabel2                  = New-Object system.Windows.Forms.Label
$settingsLabel2.text             = "Attempt to restart up to: "
$settingsLabel2.AutoSize         = $true
$settingsLabel2.height           = $height
$settingsLabel2.location         = New-Object System.Drawing.Point(20,($initLine + (5*$height) + 40))
$settingsLabel2.Font             = New-Object System.Drawing.Font($fontFamily,$fontSize)

$SettingsTextBox                   = New-Object system.Windows.Forms.TextBox
$SettingsTextBox.multiline         = $false
$SettingsTextBox.width             = 48
$SettingsTextBox.height            = $height
$SettingsTextBox.Text              = 3
$SettingsTextBox.location          = New-Object System.Drawing.Point(360,($initLine + (5*$height) + 40))
$SettingsTextBox.Font              = New-Object System.Drawing.Font($fontFamily,($fontSize+4))
$SettingsTextBox.Enabled           = $false

$settingsLabel3                  = New-Object system.Windows.Forms.Label
$settingsLabel3.text             = " time(s)"
$settingsLabel3.AutoSize         = $true
$settingsLabel3.height           = $height
$settingsLabel3.location         = New-Object System.Drawing.Point(420,($initLine + (5*$height) + 40))
$settingsLabel3.Font             = New-Object System.Drawing.Font($fontFamily,$fontSize)

# ------------------------------- Choose User -------------------------------------------------------------

$userLabel                  = New-Object system.Windows.Forms.Label
$userLabel.text             = "When running the task, use the following account: "
$userLabel.AutoSize         = $true
$userLabel.height           = $height
$userLabel.location         = New-Object System.Drawing.Point(20,($initLine + (6*$height) + 48))
$userLabel.Font             = New-Object System.Drawing.Font($fontFamily,$fontSize)

$userTextBox                   = New-Object system.Windows.Forms.TextBox
$userTextBox.AutoSize          = $true
$userTextBox.Width             = 440
$userTextBox.Height            = $height
$userTextBox.Location          = New-Object System.Drawing.Point(20,($initLine + (7*$height) + 56))
$userTextBox.Font              = New-Object System.Drawing.Font($fontFamily,($fontSize+4))
$userTextBox.Text              = $env:USERNAME

$userButton                         = New-Object system.Windows.Forms.Button
$userButton.text                    = "Change User or Group..."
$userButton.width                   = 230
$userButton.height                  = ($height + 8)
$userButton.Padding                 = 4
$userButton.Cursor                  = [System.Windows.Forms.Cursors]::Hand
$userButton.location                = New-Object System.Drawing.Point(470,($initLine + (7*$height) + 52))
$userButton.Font                    = New-Object System.Drawing.Font($fontFamily,($fontSize - 2))

# ------------------------------- Next Buttons ----------------------------------------------------
$CloseBtn1                        = New-Object system.Windows.Forms.Button
$CloseBtn1.text                   = "Close"
$CloseBtn1.width                  = 120
$CloseBtn1.height                 = 40
$CloseBtn1.Padding                = 8
$CloseBtn1.Cursor                 = [System.Windows.Forms.Cursors]::Hand
$CloseBtn1.location               = New-Object System.Drawing.Point(440,420)
$CloseBtn1.Font                   = New-Object System.Drawing.Font($fontFamily,$fontSize)

$nextBtn1                        = New-Object system.Windows.Forms.Button
$nextBtn1.text                   = "Next >"
$nextBtn1.width                  = 120
$nextBtn1.height                 = 40
$nextBtn1.Padding                = 8
$nextBtn1.Cursor                 = [System.Windows.Forms.Cursors]::Hand
$nextBtn1.location               = New-Object System.Drawing.Point(580,420)
$nextBtn1.Font                   = New-Object System.Drawing.Font($fontFamily,$fontSize)

################################################################ SELECT USERS ######################################################################

$AccountForm                        = New-Object System.Windows.Forms.Form
$AccountForm.ClientSize             = New-Object System.Drawing.Point(720,480)
$AccountForm.Text                   = "Select User or Group"
$AccountForm.TopMost                = $false

# ------------------------------------- Combine All ------------------------------------------------------------------
$AccountLabel                   = New-Object System.Windows.Forms.Label
$AccountLabel.Text              = "Select from User, Group, or Built-in security principal:"
$AccountLabel.AutoSize          = $true
$AccountLabel.Height            = $height
$AccountLabel.Location          = New-Object System.Drawing.Point(20,$initLine)
$AccountLabel.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize)

$AccountListBox                 = New-Object System.Windows.Forms.ListBox
$AccountListBox.Location        = New-Object System.Drawing.Point(20,($initLine + $height + 8))
$AccountListBox.Font            = New-Object System.Drawing.Font($fontFamily,($fontSize+4))
$AccountListBox.AutoSize        = $true
$AccountListBox.Width           = 680
$AccountListBox.BorderStyle     = [System.Windows.Forms.BorderStyle]::FixedSingle
$AccountListBox.MultiColumn     = $false
$AccountListBox.MaximumSize     = New-Object System.Drawing.Size(680,340)
        
$USERS = ((Get-LocalGroup).Name) + ((Get-LocalUser).Name)
#$USERS = @('Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor','Administrator','Users','Visitor')
$USERS | % { [void]$AccountListBox.Items.Add($_)}
$AccountListBox.ItemHeight = ($height + 4)
        

# ======================== Select Button =======================================================================

$SelectButton                        = New-Object system.Windows.Forms.Button
$SelectButton.text                   = "Select"
$SelectButton.width                  = 120
$SelectButton.height                 = 40
$SelectButton.Padding                = 8
$SelectButton.Cursor                 = [System.Windows.Forms.Cursors]::Hand
$SelectButton.location               = New-Object System.Drawing.Point(580,420)
$SelectButton.Font                   = New-Object System.Drawing.Font($fontFamily,$fontSize)
$SelectButton.Enabled                = $false
# ----------------------------- Combine All ------------------------------------------------------------------
        
$AccountForm.Controls.AddRange(@($AccountLabel,$AccountListBox,$SelectButton))

# ------------------------------------------- EVENTS -----------------------------------------------------------------
$AccountListBox.Add_SelectedIndexChanged({$SelectButton.Enabled = $true})
$SelectButton.Add_Click({
    $userTextBox.Text = $AccountListBox.SelectedItem
    $AccountForm.Close()
})

###################################################### SELECT USER END ##############################################################

# ----------------------------- Combine All -----------------------------------------------------

$Schedule.controls.AddRange(@($PathLabel,$Path,$Button1,$TaskNameLabel,$TextBox1, $durationLabel,$settingsLabel,$settingsLabel1,$settingsLabel2,$settingsLabel3,$SettingsTextBox,$ComboBox1,$ComboBox2,$userLabel,$userTextBox,$userButton,$CloseBtn1,$nextBtn1))

$Button1.Add_Click({ OpenFile })
$settingsLabel.Add_CheckStateChanged({HandleSettingsOption})
$userButton.Add_Click({SelectUserOrGroup})
$nextBtn1.Add_Click({ GotoNext1 })
$CloseBtn1.Add_Click({ $Schedule.Close() })
# ---------------------------- LOGIC ------------------------------------------------------------
function OpenFile {
    $FileOpen.ShowDialog()
    $v_filePath = $FileOpen.FileName 
    $Path.Text = $v_filePath
}
function HandleSettingsOption {
    if($settingsLabel.Checked){
       $ComboBox2.Enabled = $true
       $SettingsTextBox.Enabled = $true
    }else{
        $ComboBox2.Enabled = $false
        $SettingsTextBox.Enabled = $false
    }
}

function SelectUserOrGroup {
    # Show Dialog
    [void]$AccountForm.ShowDialog()
}

function GotoNext1 {
    $v_duration = [String]$ComboBox1.SelectedItem
    switch($v_duration){
        'Once'{
            Import-Module $OnceDialogModule
            Write-Host "Scheduling Once Task";
            try{ Show-OnceScheduler -FilePath $Path.Text -TaskName $TextBox1.Text -MainModulePath $MainModule }
            catch{ [System.Windows.MessageBox]:: Show($_.Exception.Message,'Task Scheduling Failed','OK','Error') }
            break;
        }
        'Daily'{
            Import-Module $DailyDialogModule
            Write-Host "Scheduling Daily Task"
            try{ Show-DailyScheduler -FilePath $Path.Text -TaskName $TextBox1.Text -MainModulePath $MainModule }
            catch{ [System.Windows.MessageBox]:: Show($_.Exception.Message,'Task Scheduling Failed','OK','Error') }
            break;
        }
        'Weekly'{
            Import-Module $WeeklyDialogModule
            Write-Host "Scheduling Weekly Task"
            try{ Show-WeeklyScheduler -FilePath $Path.Text -TaskName $TextBox1.Text -MainModulePath $MainModule }
            catch{ [System.Windows.MessageBox]:: Show($_.Exception.Message,'Task Scheduling Failed','OK','Error') }
            break;
        }
        'Monthly'{"Monthly selected";break;}
    }
}
# ---------- INIT -------------------------------------------------------------------------------
[void]$Schedule.ShowDialog()


<#
$Sta = New-ScheduledTaskAction cmd
$STPrin = New-ScheduledTaskPrincipal -GroupId $gp -RunLevel Highest
Register-ScheduledTask Task01 -Action $Sta -Principal $STPrin
#>