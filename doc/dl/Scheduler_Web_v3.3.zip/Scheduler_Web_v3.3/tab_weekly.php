<?php

$MainModule = __DIR__."\Schedule_Task_PHP.ps1";
$PingServerModulePath = __DIR__."\Ping_Servers_PHP.ps1";


if(isset($_POST['weekly_uploadScriptFile'])){
    $f = $_FILES['weekly_scriptFile'];

    $uploadPath = 'scripts\\';
    $ext = pathinfo($_FILES['weekly_scriptFile']['name'],PATHINFO_EXTENSION);
    $filename = $_FILES['weekly_scriptFile']['name'];
    $scriptPath = $uploadPath.$filename;			
    
    $allowed_csv_ext=array("ps1");
    if ( !in_array($ext, $allowed_csv_ext)) {
        echo '<script>alert("Please upload file in .ps1 format");</script>';
        header("Refresh:1");
    }else{
        if(file_exists($scriptPath)){
            // echo '<script>alert("File with this name already exists");</script>';
            unlink($scriptPath);
        }
        move_uploaded_file($_FILES['weekly_scriptFile']['tmp_name'], $scriptPath);
        
        $_SESSION['weekly_script_file'] = __DIR__.'\\'.$scriptPath;
    }
}

if(isset($_POST['weekly_uploadServerFile'])){
    $serverFile = $_FILES['weekly_serverFile'];

    $uploadPath = 'scripts\\';
    $ext = pathinfo($_FILES['weekly_serverFile']['name'],PATHINFO_EXTENSION);
    $filename = $_FILES['weekly_serverFile']['name'];
    $serverPath = $uploadPath.$filename;			
    
    $allowed_csv_ext=array("txt","csv");
    if ( !in_array($ext, $allowed_csv_ext)) {		
        echo '<script>alert("Please upload file in .txt or .csv format");</script>';
        header("Refresh:1");
    }else{
        if(file_exists($serverPath)){
            // echo '<script>alert("File with this name already exists");</script>';
            unlink($serverPath);
        }
        move_uploaded_file($_FILES['weekly_serverFile']['tmp_name'], $serverPath);
        
        $_SESSION['weekly_server_file'] = __DIR__.'\\'.$serverPath;
    }
}

if(isset($_POST['scheduleWeekly'])){
    if(!isset($_POST['weekly_days'])){
        echo '<script>
            alert("Please select atleast 1 Day");
            history.back(-1);
        </script>';
        exit();
    }
    $scriptAbsPath = realpath($_POST['weekly_scriptPathDisplay']);
    $serverAbsPath = realpath($_POST['weekly_serverPathDisplay']);
    
    if($scriptAbsPath){
        $weekly_taskName = $_POST['weekly_taskName'];
        $weekly_date = $_POST['weekly_date'];
        $weekly_time = $_POST['weekly_time'];
        $weekly_interval = $_POST['weekly_interval'];
        $wds = '"'.implode(' ',$_POST['weekly_days']).'"';
        $weekly_user = $_POST['weekly_user'];

        $w_command = 'powershell -File "'.$MainModule.'" -Path "'.$scriptAbsPath.'" -TaskName "'.$weekly_taskName.'" -Duration Weekly -Interval "'.$weekly_interval.'" -Time "'.$weekly_date.' '.$weekly_time.'" -WeekDays '.$wds.' -USER "'.$weekly_user.'"';
        // echo $w_command;
        
        exec($w_command, $output, $err);
        if($err){
            $W_MSG = '<div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="row" style="align-items: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                    <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                    <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                </svg>
                <strong>Failed!</strong>&nbsp;Task Failed, Try again.
            </div>
          </div>';
        }else{
            $W_MSG = '<div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="row" style="align-items: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                    <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                    <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                </svg>
                <strong>Success!</strong>&nbsp;Weekly Task Scheduled Successfully.
            </div>
          </div>';
        }
        
    }

    if(isset($_SESSION['weekly_script_file'])){
        $_SESSION['weekly_script_file'] = '';
    }
    if(isset($_SESSION['weekly_server_file'])){
        $_SESSION['weekly_server_file'] = '';
    }
}

    // Get Local User
    exec('echo %USERNAME%',$user,$u_err);
?>

<!-- modal for script file -->
<div class="modal fade" id="weekly_scriptFileModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form action="?tab=weekly" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <p><strong><span class="lead text-dange">*</span> Upload weekly Script File</strong></p>
                <div class="form-group">
                    <input type="file" name="weekly_scriptFile" id="weekly_scriptFile" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="weekly_uploadScriptFile" class="btn btn-info">Upload</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- modal for server file -->
<div class="modal fade" id="weekly_serverFileModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form action="?tab=weekly" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <p><strong>Upload Server File</strong></p>
                <div class="form-group">
                    <input type="file" name="weekly_serverFile" id="weekly_serverFile">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="weekly_uploadServerFile" class="btn btn-info">Upload</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- modal for USERS and GROUPS -->
<div class="modal fade" id="weekly_user_select" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p><strong>Select User and Group</strong></p>
                <hr>
                <select name="weekly_selected_user" id="weekly_selected_user" class="form-control">
                <?php
                    exec('powershell.exe -command (get-localgroup).name+(get-localuser).name',$users,$err);
                    if($err){echo "Can't Load Users or Groups";}
                    foreach($users as $u){
                        echo '<option value="'.$u.'">'.$u.'</option>';
                    }
                ?>
                </select>
            </div>
            <div class="modal-footer">
                <button type="submit" name="weekly_user_select_btn" id="weekly_user_select_btn" class="btn btn-primary" data-dismiss="modal">Select</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- MAIN CODE -->
<div class="container">
    <?php if(isset($W_MSG)){echo '<div class="message_box">'.$W_MSG.'</div>';}?>
    <div class="task_title">
        <span style="margin-right: 10px;">
            <i data-feather="clock" class="font-weight-bold"></i>
        </span>
        <h2 class="lead font-weight-bold">Schedule a Task for Weekly</h2>
    </div>      
    <hr>
    <form action="?tab=weekly" method="POST" id="weekly_form">
    <p><strong class="lead text-danger">*</strong> Script Path</p>
    <p class="text-small">Provide absolute path to script or browse to upload file.</p>
    <div class="row form-group">
        <div class="col col-md-10">
            <input type="text" name="weekly_scriptPathDisplay" id="weekly_scriptPathDisplay" class="form-control" value="<?php if(isset($_SESSION['weekly_script_file'])){echo $_SESSION['weekly_script_file'];}?>" required>
        </div>
        <div class="col col-md-2">
            <a class="btn btn-light" data-toggle="modal" data-target="#weekly_scriptFileModal">Browse</a>
        </div>
    </div>
    <p>Servers File</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="weekly_serverPathDisplay" id="weekly_serverPathDisplay" class="form-control" value="<?php if(isset($_SESSION['weekly_server_file'])){echo $_SESSION['weekly_server_file'];}?>">
        </div>
        <div class="col col-md-3">
            <a class="btn btn-light" data-toggle="modal" data-target="#weekly_serverFileModal">Upload Server File</a>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-6 form-group">
            <p><strong class="lead text-danger">*</strong> Task Name</p>
            <input type="text" name="weekly_taskName" id="weekly_taskName" class="form-control" required />
        </div>
        <div class="col col-md-6 form-group">
            <p class=""><strong class="lead text-danger">*</strong> Select Date and Time (UTC +5:30):</p>
            <div class="row form-group pl-3">
                <input type="text" placeholder="MM-dd-yyyy" name="weekly_date" id="weekly_date" class="form-control col col-md-7" required>
                <input type="text" placeholder="HH:mm"  name="weekly_time" id="weekly_time" class="form-control col col-md-5" required>
            </div>
        </div>
    </div>
    <div class="row form-group">
        <p class="col col-md-3"><strong class="lead text-danger">*</strong> Recur Every:</p>
        <input type="number" name="weekly_interval" id="weekly_interval" min="1" value="1" class="col col-md-2 form-control" required>
        <p class="col col-md-3">weeks</p> 
    </div>
    <p>On:</p>
    <div class="row form-group px-3">
        <?php
            $weekDays = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
            for ($wd=0; $wd < count($weekDays); $wd++) { 
                echo '
                <div class="form-check col col-md-3">
                    <input class="form-check-input" name="weekly_days[]" type="checkbox" value="'.$weekDays[$wd].'" id="weekly_day'.$wd.'">
                    <label class="form-check-label" for="weekly_day'.$wd.'">
                    '.$weekDays[$wd].'
                    </label>
                </div>';
            }
        ?>
    </div>    
    <p class="font-weight-bold">Advanced Settings</p>
    <hr>
    <p>When running this task, use this following account:</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="weekly_user" id="weekly_user" spellcheck="false" class="form-control" placeholder="<Default User> or Change" value="" readonly>
        </div>
        <div class="col col-md-3">
            <a class="btn btn-light" data-toggle="modal" data-target="#weekly_user_select">Change User or Group</a>
        </div>
    </div>
    <div class="row" style="margin-top: 60px;">
        <button type="submit" value="#" name="scheduleWeekly" class="btn btn-primary mr-3">Schedule</button>
        <button type="reset" class="btn btn-light">Cancel</button>
    </div>
    </form>
</div>

<script>
    $(document).ready(function(){
        $("#weekly_user_select_btn").on('click',function(){
            $("#weekly_user").val($("#weekly_selected_user").val());
        })
    });
</script>