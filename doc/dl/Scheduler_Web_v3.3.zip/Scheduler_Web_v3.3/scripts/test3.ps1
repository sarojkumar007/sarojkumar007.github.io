$serversFile = $PSScriptRoot + "\servers.csv"

$servers = Import-Csv $serversFile

foreach ($item in $servers)
{
    if(Test-Connection ($item.ip) -Count 1 -Quiet){
        Write-Host $item.ip " is pingable."
    }
    Start-Sleep -Seconds 2
}

Start-Sleep 10