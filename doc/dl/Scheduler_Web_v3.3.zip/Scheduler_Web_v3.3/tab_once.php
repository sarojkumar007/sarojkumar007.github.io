<?php

    $MainModule = __DIR__."\Schedule_Task_PHP.ps1";
    $PingServerModulePath = __DIR__."\Ping_Servers_PHP.ps1";
    // $Pingables = __DIR__."\servers\pingable.csv";

    if(isset($_POST['once_uploadScriptFile'])){
        $f = $_FILES['once_scriptFile'];

        $uploadPath = 'scripts\\';
        $ext = pathinfo($_FILES['once_scriptFile']['name'],PATHINFO_EXTENSION);
        $filename = $_FILES['once_scriptFile']['name'];
        $scriptPath = $uploadPath.$filename;

        $allowed_csv_ext=array("ps1");
        if ( !in_array($ext, $allowed_csv_ext)) {
            echo '
            <script>
                alert("Please upload file in .ps1 format");
            </script>
            ';
            header("Refresh:1");
        }else{
            if(file_exists($scriptPath)){
                // echo '<script>alert("File with this name already exists");</script>';
                unlink($scriptPath);
            }
            move_uploaded_file($_FILES['once_scriptFile']['tmp_name'], $scriptPath);
            
            $_SESSION['once_script_file'] = __DIR__.'\\'.$scriptPath;
        }
    }

    if(isset($_POST['once_uploadServerFile'])){
        $serverFile = $_FILES['once_serverFile'];

        $uploadPath = 'scripts\\';
        $ext = pathinfo($_FILES['once_serverFile']['name'],PATHINFO_EXTENSION);
        $filename = $_FILES['once_serverFile']['name'];
        $serverPath = $uploadPath.$filename;

        $allowed_csv_ext = array("txt","csv");
        if ( !in_array($ext, $allowed_csv_ext)) {
            echo '
            <script>
                alert("Please upload file in .csv or .txt format");
            </script>
            ';
            header("Refresh:1");
        }else{
            if(file_exists($serverPath)){
                // echo '<script>alert("File with this name already exists");</script>';
                unlink($serverPath);
            }
            move_uploaded_file($_FILES['once_serverFile']['tmp_name'], $serverPath);
            
            $_SESSION['once_server_file'] = __DIR__.'\\'.$serverPath;
        }
    }

    if(isset($_POST['scheduleOnce'])){
        $scriptAbsPath = realpath($_POST['once_scriptPathDisplay']);
        $serverAbsPath = realpath($_POST['once_serverPathDisplay']);
        
        if($scriptAbsPath){
            $once_taskName = $_POST['once_taskName'];
            $once_date = $_POST['once_date'];
            $once_time = $_POST['once_time'];
            $once_user = $_POST['once_user'];

            $command = 'powershell -File "'.$MainModule.'" -Path "'.$scriptAbsPath.'" -TaskName "'.$once_taskName.'" -Duration Once -Time "'.$once_date.' '.$once_time.'" -USER "'.$once_user.'"';

            exec($command, $output, $err);

            if($err){
                $MSG = '<div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="row" style="align-items: center;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                        <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                        <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                    </svg>
                    <strong>Failed!</strong>&nbsp;Task Failed, Try again.
                </div>
              </div>';
            }else{
                $MSG = '<div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="row" style="align-items: center;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                        <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                        <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                    </svg>
                    <strong>Success!</strong>&nbsp;Once Task Scheduled Successfully.
                </div>
              </div>';

            //   Log the Success Tasks
            // $date = date('Y_m_d_h_i_s', time());

            }

        }
        
        if(isset($_SESSION['once_script_file'])){
            $_SESSION['once_script_file'] = '';
        }
        if(isset($_SESSION['once_server_file'])){
            $_SESSION['once_server_file'] = '';
        }
    }

    // Get Local User
    exec('echo %USERNAME%',$user,$u_err);
?>

<!-- ################################################################### -->

<!-- modal for script file -->
<div class="modal fade" id="once_scriptFileModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form action="?tab=once" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <p><strong><span class="lead text-danger">*</span> Upload Script File</strong></p>
                <div class="form-group">
                    <input type="file" name="once_scriptFile" id="once_scriptFile" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="once_uploadScriptFile" class="btn btn-info">Upload</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- modal for server file -->
<div class="modal fade" id="once_serverFileModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form action="?tab=once" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <p><strong>Upload Server File</strong></p>
                <div class="form-group">
                    <input type="file" name="once_serverFile" id="once_serverFile">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="once_uploadServerFile" class="btn btn-info">Upload</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- modal for USERS and GROUPS -->
<div class="modal fade" id="once_user_select" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p><strong>Select User and Group</strong></p>
                <hr>
                <select name="once_selected_user" id="once_selected_user" class="form-control">
                <?php
                    exec('powershell.exe -command (get-localgroup).name+(get-localuser).name',$users,$err);
                    if($err){echo "Can't Load Users or Groups";}
                    foreach($users as $u){
                        echo '<option value="'.$u.'">'.$u.'</option>';
                    }
                ?>
                </select>
            </div>
            <div class="modal-footer">
                <button type="submit" name="once_user_select_btn" id="once_user_select_btn" class="btn btn-primary" data-dismiss="modal">Select</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ############################################################# -->
<div class="container">
    <?php if(isset($MSG)){echo '<div class="message_box">'.$MSG.'</div>';}?>
    <div class="task_title">
        <span style="margin-right: 10px;">
            <i data-feather="clock" class="font-weight-bold"></i>
        </span>
        <h2 class="lead font-weight-bold">Schedule a Task for Once</h2>
    </div>
    <hr>
    <form action="?tab=once" method="POST">
    <p><strong class="lead text-danger">*</strong> Script Path</p>
    <p class="text-small">Provide absolute path to script or browse to upload file.</p>
    <div class="row form-group">
        <div class="col col-md-11">
            <input type="text" name="once_scriptPathDisplay" id="once_scriptPathDisplay" class="form-control" value="<?php if(isset($_SESSION['once_script_file'])){echo $_SESSION['once_script_file'];}?>" required>
        </div>
        <div class="col col-md-1">
            <a class="btn btn-light" data-toggle="modal" data-target="#once_scriptFileModal">Browse</a>
        </div>
    </div>
    <p>Servers File</p>
    <div class="row form-group">
        <div class="col col-md-10">
            <input type="text" name="once_serverPathDisplay" id="once_serverPathDisplay" class="form-control" value="<?php if(isset($_SESSION['once_server_file'])){echo $_SESSION['once_server_file'];}?>">
        </div>
        <div class="col col-md-2">
            <a class="btn btn-light" data-toggle="modal" data-target="#once_serverFileModal">Upload Server File</a>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-6 form-group">
            <p><strong class="lead text-danger">*</strong> Task Name</p>
            <input type="text" name="once_taskName" id="once_taskName" class="form-control" required />
        </div>
        <div class="col col-md-6 form-group">
            <p for="" class=""><strong class="lead text-danger">*</strong> Select Date (MM-dd-yyyy) and Time (24Hrs) (UTC +5:30):</p>
            <div class="row form-group pl-3">
                <input type="text" placeholder="MM-dd-yyyy" name="once_date" id="once_date" class="form-control col col-md-7" required>
                <input type="text" placeholder="HH:mm" name="once_time" id="once_time" class="form-control col col-md-5" required>
            </div>
        </div>
    </div>
    <p class="font-weight-bold">Advanced Settings</p>
    <hr>
    <p>When running this task, use this following account:</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="once_user" id="once_user" spellcheck="false" class="form-control" placeholder="<Default User> or Change" value="<?php echo $user[0]; ?>" readonly>
        </div>
        <div class="col col-md-3">
            <a class="btn btn-light" data-toggle="modal" data-target="#once_user_select">Change User or Group</a>
        </div>
    </div>
    <!-- <div class="form-group">
        <h4>Settings:</h4>
        <p class="text-muted">If task fails, restart every: 5 Minutes for 1 times</p>
    </div> -->
    <div class="row" style="margin-top: 40px;">
        <button type="submit" name="scheduleOnce" class="btn btn-primary mr-3">Schedule</button>
        <button type="reset" class="btn btn-light">Cancel</button>
    </div>
    </form>
</div>
<script>
    $(document).ready(function(){
        $("#once_user_select_btn").on('click',function(){
            $("#once_user").val($("#once_selected_user").val());
        })
    });
</script>
