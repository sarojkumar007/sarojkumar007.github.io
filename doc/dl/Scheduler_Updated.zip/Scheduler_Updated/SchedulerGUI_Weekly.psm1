﻿function Show-WeeklyScheduler
{
    [CmdletBinding()]
    [Alias()]
    Param
    (
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)][String]$FilePath,
        [Parameter(Mandatory=$true,Position=1)][String]$TaskName
    )
    Begin
    {
        Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
        Import-Module "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\Schedule-Task.psm1" -wa Ignore
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.Application]::EnableVisualStyles()
        
        # Global Changes
        $fontFamily = "Calisto MT"
        $fontSize = 12
        $height = 30
        $initLine = 30
    }
    Process
    {
        $WeeklyForm                        = New-Object system.Windows.Forms.Form
        $WeeklyForm.ClientSize             = New-Object System.Drawing.Point(640,320)
        $WeeklyForm.text                   = "Schedule a Task"
        $WeeklyForm.AutoSize               = $true
        $WeeklyForm.TopMost                = $false
        
        $WeeklyFileLabel                   = New-Object system.Windows.Forms.Label
        $WeeklyFileLabel.text              = "Script Path"
        $WeeklyFileLabel.AutoSize          = $true
        $WeeklyFileLabel.width             = 60
        $WeeklyFileLabel.height            = $height
        $WeeklyFileLabel.location          = New-Object System.Drawing.Point(20,$initLine)
        $WeeklyFileLabel.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $WeeklyFilePath                    = New-Object system.Windows.Forms.Label
        $WeeklyFilePath.text               = $FilePath
        $WeeklyFilePath.AutoSize           = $true
        $WeeklyFilePath.height             = $height
        $WeeklyFilePath.location           = New-Object System.Drawing.Point(190,$initLine)
        $WeeklyFilePath.Font               = New-Object System.Drawing.Font($fontFamily,($fontSize - 1))

        $WeeklyLabel                       = New-Object system.Windows.Forms.Label
        $WeeklyLabel.text                  = "Select DateTime"
        $WeeklyLabel.AutoSize              = $true
        $WeeklyLabel.width                 = 25
        $WeeklyLabel.height                = $height
        $WeeklyLabel.location              = New-Object System.Drawing.Point(20,($initLine + $height + 8))
        $WeeklyLabel.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $datePicker                        = New-Object System.Windows.Forms.DateTimePicker
        $datePicker.Width = 240
        $datePicker.Height = 32
        $datePicker.Format                 = [windows.forms.datetimepickerFormat]::custom
        $datePicker.CustomFormat           = “MM/dd/yyyy HH:mm”
        $datePicker.Location               = New-Object System.Drawing.Point(240,($initLine + $height + 8))
        $datePicker.Font                   = New-Object System.Drawing.Font($fontFamily,($fontSize+1))
        $WeeklyInterval                    = New-Object system.Windows.Forms.Label
        $WeeklyInterval.text               = "Recur every "
        $WeeklyInterval.AutoSize           = $true
        $WeeklyInterval.width              = 25
        $WeeklyInterval.height             = $height
        $WeeklyInterval.location           = New-Object System.Drawing.Point(20,($initLine + (2*$height) + 16))
        $WeeklyInterval.Font               = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $WeeklyRecur                       = New-Object system.Windows.Forms.TextBox
        $WeeklyRecur.multiline             = $false
        $WeeklyRecur.width                 = 48
        $WeeklyRecur.height                = $height
        $WeeklyRecur.location              = New-Object System.Drawing.Point(240,($initLine + (2*$height) + 16))
        $WeeklyRecur.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $WeeklyInterval2                   = New-Object system.Windows.Forms.Label
        $WeeklyInterval2.text              = "Weeks on:"
        $WeeklyInterval2.AutoSize          = $true
        $WeeklyInterval2.height            = $height
        $WeeklyInterval2.location          = New-Object System.Drawing.Point(308,($initLine + (2*$height) + 16))
        $WeeklyInterval2.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize)
        
        <#
        $weekDays1                         = New-Object system.Windows.Forms.ComboBox
        $weekDays1.text                    = "Select"
        $weekDays1.width                   = 100
        $weekDays1.height                  = $height
        @('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') | ForEach-Object {[void] $weekDays1.Items.Add($_)}
        $weekDays1.location                = New-Object System.Drawing.Point(240,($initLine + (3*$height) + 24))
        $weekDays1.Font                    = New-Object System.Drawing.Font($fontFamily,$fontSize)
        #>
        $checkBoxes = @()
        $wDays = @('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')
        $cHeight = ($initLine + (3*$height) + 24)
        for ($i = 1; $i -lt ($wDays.Length + 1); $i++)
        {
            $CheckBox                       = New-Object system.Windows.Forms.CheckBox
            $CheckBox.text                  = $wDays[$i-1]
            $CheckBox.AutoSize              = $false
            $CheckBox.width                 = 160
            $CheckBox.height                = $height
            if($i -lt 5){
                $CheckBox.location          = New-Object System.Drawing.Point((145+($i*160)),$cHeight)
            }else{
                $CheckBox.location          = New-Object System.Drawing.Point(((($i-4)*160)+$cHeight),($cHeight + $height + 8))
            }
            $CheckBox.Font                  = New-Object System.Drawing.Font($fontFamily,($fontSize-1))
            $checkBoxes += $CheckBox
        }

        $WeeklySubmit                      = New-Object system.Windows.Forms.Button
        $WeeklySubmit.text                 = "Schedule"
        $WeeklySubmit.width                = 120
        $WeeklySubmit.height               = 30
        $WeeklySubmit.Cursor                 = [System.Windows.Forms.Cursors]::Hand
        $WeeklySubmit.location             = New-Object System.Drawing.Point(500,270)
        $WeeklySubmit.Font                 = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $WeeklyForm.controls.AddRange((@($WeeklyFileLabel,$WeeklyFilePath,$WeeklyLabel,$datePicker,$WeeklyInterval,$WeeklyRecur,$WeeklyInterval2,$weekDays1,$WeeklySubmit) + $checkBoxes))
        $WeeklySubmit.Add_Click({ ScheduleWeeklyTask })
        function ScheduleWeeklyTask {
            if([int]($WeeklyRecur.Text)){
                $wkDays = @()
                foreach ($cb in $checkBoxes)
                {
                    if($cb.Checked){$wkDays += $cb.Text}
                }
                Schedule-Task -Path $FilePath -TaskName $TaskName -Duration Weekly -Interval ([int]($WeeklyRecur.Text)) -Time (Get-Date -Date $datePicker.Text) -WeekDays $wkDays
                $res = [System.Windows.MessageBox]::Show('Task Scheduled successfully!','Task Scheduled','OK','Info')
                if($res -eq "OK"){
                    $WeeklyForm.Close()
                }
            }
            else{Write-Host "Enter valid recur weeks" -fore Red}
        }
        [void]$WeeklyForm.ShowDialog()
    }
}