﻿Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
# Global Changes
$fontFamily = "Calisto MT"
$fontSize = 12
$height = 30
$initLine = 30
$OnceDialogModule = "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\SchedulerGUI_Once.psm1"
$DailyDialogModule = "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\SchedulerGUI_Daily.psm1"
$WeeklyDialogModule = "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\SchedulerGUI_Weekly.psm1"
# FORM
$Schedule                        = New-Object System.Windows.Forms.Form
$Schedule.ClientSize             = New-Object System.Drawing.Point(720,320)
$Schedule.Text                   = "Schedule a Task"
$Schedule.StartPosition          = "CenterScreen"
$Schedule.TopMost                = $false
# ------------------------------ Script Path -------------------------------------------
$PathLabel                       = New-Object System.Windows.Forms.Label
$PathLabel.Text                  = "Script Path"
$PathLabel.AutoSize              = $true
$PathLabel.Height                = $height
$PathLabel.Location              = New-Object System.Drawing.Point(20,$initLine)
$PathLabel.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)
$Path                            = New-Object system.Windows.Forms.TextBox
$Path.multiline                  = $false
$Path.width                      = 340
$Path.height                     = $height
$Path.location                   = New-Object System.Drawing.Point(180,$initLine)
$Path.Font                       = New-Object System.Drawing.Font($fontFamily,($fontSize+2))
$Button1                         = New-Object system.Windows.Forms.Button
$Button1.text                    = "Browse"
$Button1.width                   = 140
$Button1.height                  = ($height + 8)
$Button1.location                = New-Object System.Drawing.Point(560,($initLine - 4))
$Button1.Font                    = New-Object System.Drawing.Font($fontFamily,$fontSize)
$FileOpen = New-Object System.Windows.Forms.OpenFileDialog
$FileOpen.Filter = "PowerShell Scripts(*.ps1)|*.ps1"
# ------------------------------ Task Name ------------------------------------------------
$TaskNameLabel                   = New-Object system.Windows.Forms.Label
$TaskNameLabel.text              = "Task Name"
$TaskNameLabel.AutoSize          = $true
$TaskNameLabel.width             = 25
$TaskNameLabel.height            = $height
$TaskNameLabel.location          = New-Object System.Drawing.Point(20,($initLine + $height + 8))
$TaskNameLabel.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize)
$TextBox1                        = New-Object system.Windows.Forms.TextBox
$TextBox1.multiline              = $false
$TextBox1.width                  = 340
$TextBox1.height                 = $height
$TextBox1.location               = New-Object System.Drawing.Point(180,($initLine + $height + 8))
$TextBox1.Font                   = New-Object System.Drawing.Font($fontFamily,($fontSize+2))
# ------------------------------ Duration ----------------------------------------------------
$durationLabel                   = New-Object system.Windows.Forms.Label
$durationLabel.text              = "Duration"
$durationLabel.AutoSize          = $true
$durationLabel.width             = 25
$durationLabel.height            = 20
$durationLabel.location          = New-Object System.Drawing.Point(20,($initLine + (2*$height) + 16))
$durationLabel.Font              = New-Object System.Drawing.Font($fontFamily,$fontSize)
$ComboBox1                       = New-Object system.Windows.Forms.ComboBox
$ComboBox1.text                  = "Select"
$ComboBox1.width                 = 100
$ComboBox1.height                = $height
@('Once','Daily','Weekly','Monthly') | ForEach-Object {[void] $ComboBox1.Items.Add($_)}
$ComboBox1.location              = New-Object System.Drawing.Point(180,($initLine + (2*$height) + 16))
$ComboBox1.Font                  = New-Object System.Drawing.Font($fontFamily,($fontSize+2))
$ComboBox1.Padding               = 30
# ----------------------------- Next Button ----------------------------------------------------
$CloseBtn1                        = New-Object system.Windows.Forms.Button
$CloseBtn1.text                   = "Close"
$CloseBtn1.width                  = 120
$CloseBtn1.height                 = 32
$CloseBtn1.Cursor                 = [System.Windows.Forms.Cursors]::Hand
$CloseBtn1.location               = New-Object System.Drawing.Point(440,270)
$CloseBtn1.Font                   = New-Object System.Drawing.Font($fontFamily,$fontSize)

$nextBtn1                        = New-Object system.Windows.Forms.Button

$nextBtn1.text                   = "Next >"
$nextBtn1.width                  = 120
$nextBtn1.height                 = 32
$nextBtn1.Cursor                 = [System.Windows.Forms.Cursors]::Hand
$nextBtn1.location               = New-Object System.Drawing.Point(580,270)
$nextBtn1.Font                   = New-Object System.Drawing.Font($fontFamily,$fontSize)
# ----------------------------- Combine All -----------------------------------------------------
$Schedule.controls.AddRange(@($PathLabel,$Path,$Button1,$TaskNameLabel,$TextBox1, $durationLabel,$ComboBox1,$CloseBtn1,$nextBtn1))
$Button1.Add_Click({ OpenFile })
$nextBtn1.Add_Click({ GotoNext1 })
$CloseBtn1.Add_Click({ $Schedule.Close() })
# ---------------------------- LOGIC ------------------------------------------------------------
function OpenFile {
    $FileOpen.ShowDialog()
    $v_filePath = $FileOpen.FileName 
    $Path.Text = $v_filePath
}
function GotoNext1 {
    $v_duration = [String]$ComboBox1.SelectedItem
    switch($v_duration){
        'Once'{
            Import-Module $OnceDialogModule
            Write-Host "Once selected";
            Show-OnceScheduler -FilePath $Path.Text -TaskName $TextBox1.Text
            break;
        }
        'Daily'{
            Import-Module $DailyDialogModule
            Write-Host "Daily selected"
            Show-DailyScheduler -FilePath $Path.Text -TaskName $TextBox1.Text
            break;
        }
        'Weekly'{
            Import-Module $WeeklyDialogModule
            Write-Host "Weekly selected"
            Show-WeeklyScheduler -FilePath $Path.Text -TaskName $TextBox1.Text
            break;
        }
        'Monthly'{"Monthly selected";break;}
    }
}
# ---------- INIT -------------------------------------------------------------------------------
[void]$Schedule.ShowDialog()