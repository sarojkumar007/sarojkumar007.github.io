﻿function Show-OnceScheduler
{
    [CmdletBinding()]
    [Alias()]
    Param
    (
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)][String]$FilePath,
        [Parameter(Mandatory=$true,Position=1)][String]$TaskName
    )
    Begin
    {
        Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
        Import-Module "C:\Users\sarojkumar.sahoo\Downloads\WORK\practice\Scheduler\Schedule-Task.psm1" -wa Ignore
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.Application]::EnableVisualStyles()
        
        # Global Changes
        $fontFamily = "Calisto MT"
        $fontSize = 12
        $height = 30
        $initLine = 30
    }
    Process
    {
        $OnceForm                        = New-Object system.Windows.Forms.Form
        $OnceForm.ClientSize             = New-Object System.Drawing.Point(640,320)
        $OnceForm.text                   = "Schedule a Task"
        $OnceForm.TopMost                = $false
        
        $OnceFileLabel                       = New-Object system.Windows.Forms.Label
        $OnceFileLabel.text                  = "Script Path"
        $OnceFileLabel.AutoSize              = $true
        $OnceFileLabel.width                 = 60
        $OnceFileLabel.height                = $height
        $OnceFileLabel.location              = New-Object System.Drawing.Point(20,$initLine)
        $OnceFileLabel.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $OnceFilePath                       = New-Object system.Windows.Forms.Label
        $OnceFilePath.text                  = $FilePath
        $OnceFilePath.AutoSize              = $true
        $OnceFilePath.width                 = 60
        $OnceFilePath.height                = $height
        $OnceFilePath.location              = New-Object System.Drawing.Point(240,$initLine)
        $OnceFilePath.Font                  = New-Object System.Drawing.Font($fontFamily,($fontSize - 1))

        $OnceLabel                       = New-Object system.Windows.Forms.Label
        $OnceLabel.text                  = "Select DateTime"
        $OnceLabel.AutoSize              = $true
        $OnceLabel.width                 = 25
        $OnceLabel.height                = $height
        $OnceLabel.location              = New-Object System.Drawing.Point(20,($initLine + $height + 8))
        $OnceLabel.Font                  = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $datePicker                      = New-Object System.Windows.Forms.DateTimePicker
        $datePicker.Width = 240
        $datePicker.Height = 32
        $datePicker.Format               = [windows.forms.datetimepickerFormat]::custom
        $datePicker.CustomFormat         = “MM/dd/yyyy HH:mm”
        $datePicker.Location             = New-Object System.Drawing.Point(240,($initLine + $height + 8))
        $datePicker.Font                 = New-Object System.Drawing.Font($fontFamily,($fontSize+1))
        $OnceSubmit                      = New-Object system.Windows.Forms.Button
        $OnceSubmit.text                 = "Schedule"
        $OnceSubmit.width                = 120
        $OnceSubmit.height               = 32
        $OnceSubmit.Cursor                 = [System.Windows.Forms.Cursors]::Hand
        $OnceSubmit.location             = New-Object System.Drawing.Point(500,270)
        $OnceSubmit.Font                 = New-Object System.Drawing.Font($fontFamily,$fontSize)
        $OnceForm.controls.AddRange(@($OnceFileLabel,$OnceFilePath,$OnceLabel,$datePicker,$OnceSubmit))
        $OnceSubmit.Add_Click({ ScheduleOnceTask })
        function ScheduleOnceTask {
            Schedule-Task -Path $FilePath -TaskName $TaskName -Duration Once -Time (Get-Date -Date $datePicker.Text)
            $res = [System.Windows.MessageBox]:: Show('Task Scheduled successfully!','Task Scheduled','OK','Info')
            if($res -eq 'OK'){
                $OnceForm.Close()
            }
        }
        [void]$OnceForm.ShowDialog()
    }
}