<?php

    include('_config.php');

    $MainModule = __DIR__."\Schedule_Task_PHP.ps1";
    $PingServerModulePath = __DIR__."\Ping_Servers_PHP.ps1";
    
    $scriptPath = '';
    $serverPath = '';

    // Get Local User
    exec('echo %USERNAME%',$user,$u_err);

    if(isset($_POST['scheduleOnce'])){
        $once_scriptFile = $_FILES['once_scriptFile'];
        $once_serverFile = $_FILES['once_serverFile'];
        $once_taskName = $_POST['once_taskName'];
        $once_date = $_POST['once_date'];
        $once_time = $_POST['once_time'];
        $once_user = $_POST['once_user'];

        $once_TaskPath = __DIR__."\scripts\\".$once_taskName."\\";

        if(file_exists($once_TaskPath)){
            echo "<script>alert('Folder with same TaskName exists.')</script>";
            header("Refresh:1");
        }
        else{
            mkdir($once_TaskPath);

            $script_ext = pathinfo($once_scriptFile['name'],PATHINFO_EXTENSION);
            if($once_serverFile['name']){$server_ext = pathinfo($once_serverFile['name'],PATHINFO_EXTENSION);}

            $script_filename = $_FILES['once_scriptFile']['name'];
            if($once_serverFile['name']){$server_filename = $_FILES['once_serverFile']['name'];}
            
            $scriptPath = $once_TaskPath.$script_filename;
            if($once_serverFile['name']){$serverPath = $once_TaskPath.$server_filename;}

            $allowed_script_ext = array("ps1");
            if($once_serverFile['name']){$allowed_server_ext = array("txt","csv");}

            if (!in_array($script_ext, $allowed_script_ext)) {
                echo '
                <script>
                    alert("Please upload file in .ps1 format");
                </script>
                ';
                header("Refresh:1");
            }
            if ($once_serverFile['name'] and (!in_array($server_ext, $allowed_server_ext))) {
                echo '
                <script>
                    alert("Please upload file in .txt and .csv format");
                </script>
                ';
                header("Refresh:1");
            }
            move_uploaded_file($once_scriptFile['tmp_name'],$scriptPath);
            if($once_serverFile['name']){move_uploaded_file($once_serverFile['tmp_name'],$serverPath);}
        }
        

        $command = 'powershell.exe -File "'.$MainModule.'" -Path "'.$scriptPath.'" -TaskName "'.$once_taskName.'" -Duration Once -Time "'.$once_date.' '.$once_time.'" -USER "'.$once_user.'"';

        exec($command, $output, $err);

        if($err){
            $MSG = '<div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="row" style="align-items: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                    <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                    <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                </svg>
                <strong>Failed!</strong>&nbsp;Task Failed, Try again.
            </div>
            </div>';
        }else{

            //   Log the Success Tasks
            // echo date_default_timezone_get();
            date_default_timezone_set("Asia/Kolkata");
            $date = date('Y-m-d H:i:s', time());
            $db = new DBConnect\CRUD("localhost","root","","scheduler");
            $table = "report";
            $colArr = array('TaskName','Author','isDeleted','Created');
            $valArr = array($once_taskName,$user[0],'0',$date);

            $item = $db->INSERT_VAL($table,$colArr,$valArr);
            
            $MSG = '<div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="row" style="align-items: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                    <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                    <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                </svg>
                <strong>Success!</strong>&nbsp;Once Task Scheduled Successfully.
            </div>
            </div>';

        }
    }
?>

<!-- ################################################################### -->

<!-- modal for USERS and GROUPS -->
<div class="modal fade" id="once_user_select" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p><strong>Select User and Group</strong></p>
                <hr>
                <select name="once_selected_user" id="once_selected_user" class="form-control">
                <?php
                    exec('powershell.exe -command (get-localgroup).name+(get-localuser).name',$users,$err);
                    if($err){echo "Can't Load Users or Groups";}
                    $users = array_merge($users,array("SYSTEM","LOCAL SERVICE","NETWORK SERVICE"));
                    foreach($users as $u){
                        echo '<option value="'.$u.'">'.$u.'</option>';
                    }
                ?>
                </select>
            </div>
            <div class="modal-footer">
                <button type="submit" name="once_user_select_btn" id="once_user_select_btn" class="btn btn-primary" data-dismiss="modal">Select</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ############################################################# -->
<div class="container">
    <?php if(isset($MSG)){echo '<div class="message_box">'.$MSG.'</div>';}?>
    <div class="task_title">
        <span style="margin-right: 10px;">
            <i data-feather="clock" class="font-weight-bold"></i>
        </span>
        <h2 class="lead font-weight-bold">Schedule a Task for Once</h2>
    </div>
    <hr>
    <form action="?tab=once" method="POST" enctype="multipart/form-data">
    <p><strong class="lead text-danger">*</strong> Script Path (<small>Provide PowerShell file(.ps1) only</small>)</p>
    <div class="row form-group">
        <div class="col col-md-11">
            <input type="text" name="once_scriptPathDisplay" id="once_scriptPathDisplay" class="form-control" value="" required readonly spellcheck="false" autocomplete="off">
        </div>
        <div class="col col-md-1">
            <input type="file" name="once_scriptFile" id="once_scriptFile" class="d-none" required>
            <label for="once_scriptFile" class="btn btn-light">Browse</label>
        </div>
    </div>
    <p>Servers File (<small>Provide only .txt or .csv file </small>)</p>
    <div class="row form-group">
        <div class="col col-md-10">
            <input type="text" name="once_serverPathDisplay" id="once_serverPathDisplay" class="form-control" value="" readonly spellcheck="false" autocomplete="off">
        </div>
        <div class="col col-md-2">
            <input type="file" name="once_serverFile" id="once_serverFile" class="d-none">
            <label for="once_serverFile" class="btn btn-light">Upload Server File</label>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-6 form-group">
            <p><strong class="lead text-danger">*</strong> Task Name</p>
            <input type="text" name="once_taskName" id="once_taskName" class="form-control" required spellcheck="false" autocomplete="off" />
        </div>
        <div class="col col-md-6 form-group">
            <p for="" class=""><strong class="lead text-danger">*</strong> Select Date (<small>MM/DD/YYYY</small>) and Time (<small>24Hrs</small>) (UTC +5:30):</p>
            <div class="row form-group pl-3">
                <input type="text" placeholder="MM/DD/YYYY" name="once_date" id="once_date" class="form-control col col-md-7" required  autocomplete="off">
                <input type="text" placeholder="HH:mm" name="once_time" id="once_time" class="form-control col col-md-5" required autocomplete="off">
            </div>
        </div>
    </div>
    <p class="font-weight-bold">Advanced Settings</p>
    <hr>
    <p>When running this task, use this following account:</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="once_user" id="once_user" spellcheck="false" class="form-control" placeholder="<Default User> or Change" value="<?php echo $user[0]; ?>" readonly>
        </div>
        <div class="col col-md-3">
            <a class="btn btn-light" data-toggle="modal" data-target="#once_user_select">Change User or Group</a>
        </div>
    </div>
    <!-- <div class="form-group">
        <h4>Settings:</h4>
        <p class="text-muted">If task fails, restart every: 5 Minutes for 1 times</p>
    </div> -->
    <div class="row" style="margin-top: 40px;">
        <button type="submit" name="scheduleOnce" class="btn btn-primary mr-3">Schedule</button>
        <button type="reset" class="btn btn-light">Cancel</button>
    </div>
    </form>
</div>
<script>
    $(document).ready(function(){
        $("#once_user_select_btn").on('click',function(){
            $("#once_user").val($("#once_selected_user").val());
        })
        document.getElementById('once_scriptFile').onchange = function(e){
            document.getElementById('once_scriptPathDisplay').value = e.target.files[0].name
        }
        document.getElementById('once_serverFile').onchange = function(e){
            document.getElementById('once_serverPathDisplay').value = e.target.files[0].name
        }
    });
</script>
