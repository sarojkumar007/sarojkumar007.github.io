<?php
    include('../_config.php');

    $db = new DBConnect\CRUD("localhost","root","","scheduler");
    $table = "report";
    $colArr = array('*');
    $condition = "";

    $res = $db->FETCH_DATA($table,$colArr,$condition,1);

    // Convert Current URL to Back URL
    $url = $_SERVER['REQUEST_URI'];
    $url = explode("/",$url);
    array_pop($url);
    array_pop($url);
    $url = "http://localhost".implode("/",$url);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduler Report</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../datatables/css/jquery.dataTables.min.css">
    <style>
        .table_report tr th,
        .table_report tr td{
            text-align:center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-light shadow bg-light">
        <a class="navbar-brand d-flex align-items-center font-weight-bold" href="#">
            <i data-feather="file-text" class="font-weight-bold"></i>
            &nbsp;Scheduler Report
        </a>
        <div class="navbar-nav right">
            <a class="nav-link text-primary" href="<?php echo $url; ?>">&larr; Back to Scheduler</a>
        </div>
    </nav>
    <div class="container py-3">
        <div class="jumbotron bg-info text-light d-flex align-items-center justify-content-center p-3">
            <h3>Scheduled Task Report</h3>
        </div>
        <div class="delete_status"></div>
        <table id="reportTable" class="table table-striped table_report">
            <thead>
                <tr>
                    <th>Sl. No</th>
                    <th>TaskName</th>
                    <th>Author</th>
                    <th>Created Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                
                    function getDeleteButton($isDel,$taskName){
                        if($isDel == 1){
                            return '<span class="text-muted" title="Task already Deleted">
                                <i data-feather="trash-2" class="font-weight-bold"></i>
                            </span>';
                        }
                        else{
                            return '<span class="text-danger" title="Remove Task" onclick="UnRegisterTask(\''.$taskName.'\')" style="cursor: pointer">
                                <i data-feather="trash-2" class="font-weight-bold"></i>
                            </span>';
                        }
                    }

                    for ($i=0; $i < count($res); $i++) {
                        
                        $row = $res[$i];

                        echo '<tr>
                            <td>'.($i+1).'</td>
                            <td>'.$row['TaskName'].'</td>
                            <td>'.$row['Author'].'</td>
                            <td>'.$row['Created'].'</td>
                            <td>
                                '.getDeleteButton($row['isDeleted'],$row['TaskName']).'
                            </td>
                        </tr>';
                    }
                    
                ?>
            </tbody>
        </table>
    </div>

    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/feather.min.js"></script>
    <script src="../datatables/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            feather.replace();
			$('#reportTable').DataTable();
		});

        function UnRegisterTask (taskName){
            if(confirm('Task will be deleted from Scheduler. Click OK to Continue.')){
                $('.delete_status').html('<div class="alert alert-warning" role="alert">Deleting '+taskName+' ...</div>');
                $.ajax({
                    url: "../_ajax.php",
                    type: "POST",
                    data: "TaskName=" + taskName,
                    success: function (res){
                        $('.delete_status').html('<div class="alert alert-danger alert-dismissible fade show" role="alert"><strong>Success: </strong> '+res+'<a type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></a></div>');
                        console.log(res);
                        setTimeout(function (){
                            location.reload();
                        }, 1500);
                    }
                });
            }
        }
    </script>
</body>
</html>