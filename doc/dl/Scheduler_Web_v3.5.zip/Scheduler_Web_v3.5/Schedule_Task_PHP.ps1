﻿Param(
    [Parameter(Mandatory=$true)][string]$Path,
    [Parameter(Mandatory=$true)][string]$TaskName,
    [Parameter(Mandatory=$true)][ValidateSet("Once","Daily","Weekly","Monthly")][String]$Duration,
    [String]$Interval,
    [String]$WeekDays,
    [Parameter(Mandatory=$true)][String]$Time,
    [ValidateSet("Indefinitely","15 Minutes","30 Minutes","1 Hour","12 Hours","1 Day")][String]$RecurEvery,
    [ValidateSet("5 Minutes","10 Minutes","15 Minutes","30 Minutes","1 Hour")][String]$RecurInterval,
    [String]$USER
)

####### Func for Scheduling --------------------------------------------------------------------------------------
function Schedule-Task
{
    [CmdletBinding()]
    [Alias('schtsk')]
    
    Param
    (
        [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true,Position=0)][string]$Path,
        [Parameter(Mandatory=$true)][string]$TaskName,
        [Parameter(Mandatory=$true)][ValidateSet("Once","Daily","Weekly")][String]$Duration,
        [int]$Interval,
        [ValidateSet("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")][String[]]$WeekDays,
        [Parameter(Mandatory=$true)][DateTime]$Time,
        [ValidateSet("Indefinitely","15 Minutes","30 Minutes","1 Hour","12 Hours","1 Day")][String]$RecurEvery,
        [ValidateSet("5 Minutes","10 Minutes","15 Minutes","30 Minutes","1 Hour")][String]$RecurInterval,
        [String]$USER
    )
   
    Process
    {
    Write-Warning "Run this script with admin access."
    try{
        if((Test-Path $Path) -and ([System.IO.Path]::GetExtension($Path) -eq '.ps1'))
        {
            $psPath = (Resolve-Path -Path $Path).Path
            
            ## ---------------------------- CREATE TASK ACTION ---------------------------------------------------------
            
            $task= New-ScheduledTaskAction -Execute powershell.exe -Argument $psPath
            $STSet = New-ScheduledTaskSettingsSet  -RunOnlyIfNetworkAvailable -DontStopIfGoingOnBatteries -RestartCount:1 -RestartInterval (New-TimeSpan -Minutes 5) -ExecutionTimeLimit (New-TimeSpan -Hours 1) -StartWhenAvailable
            $STSet.DisallowStartIfOnBatteries =$false
            $STPrin = ''

            if($USER){
                Write-Host "Setting Prici"
                $localUsers = (Get-LocalUser).name

                if($localUsers -contains $USER)
                {
                    $STPrin = New-ScheduledTaskPrincipal -UserId $USER -RunLevel Highest
                }
                else
                {
                    $STPrin = New-ScheduledTaskPrincipal -GroupId $USER -RunLevel Highest
                }
            }

            if($Duration){
                switch($Duration){
                # ONCE TASK
                    'Once'{
                        $trg= New-ScheduledTaskTrigger -Once -At $Time
                        
                        try{
                            if($USER){
                                Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Principal $STPrin -Trigger $trg -Settings $STSet -ea Stop
                            }
                            else{
                                Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Trigger $trg -Settings $STSet -ea Stop
                            }
                        }
                        catch{return "Error: $($_.Exception.Message)"}
                    }
                # DAILY TASK
                    'Daily'{
                        $trg = New-ScheduledTaskTrigger -Daily -DaysInterval $Interval -At $Time
                        if($RecurEvery -and $RecurInterval){
                            $rInterval = ''
                            switch($RecurInterval){
                                "5 Minutes"{$rInterval = New-TimeSpan -Minutes 5;break;}
                                "10 Minutes"{$rInterval = New-TimeSpan -Minutes 10; break;}
                                "15 Minutes"{$rInterval = New-TimeSpan -Minutes 15; break;}
                                "30 Minutes"{$rInterval = New-TimeSpan -Minutes 30; break;}
                                "1 Hour"{$rInterval = New-TimeSpan -Hours 1; break;}
                                default{break;}
                            }
                            $rEvery = ''
                            switch($RecurEvery){
                                "15 Minutes"{$rEvery = New-TimeSpan -Minutes 15;break;}
                                "30 Minutes"{$rEvery = New-TimeSpan -Minutes 30;break;}
                                "1 Hour"{$rEvery = New-TimeSpan -Hours 1;break;}
                                "12 Hours"{$rEvery = New-TimeSpan -Hours 12;break;}
                                "1 Day"{$rEvery = New-TimeSpan -Days 1;break;}
                                default{break;}
                            }
                            if($rEvery){
                                $trg.Repetition = (New-ScheduledTaskTrigger -Once -At $Time -RepetitionDuration $rEvery -RepetitionInterval $rInterval).Repetition
                            } 
                            else{
                                $trg.Repetition = (New-ScheduledTaskTrigger -Once -At $Time -RepetitionInterval $rInterval).Repetition
                            }
                        }
                        try{                        
                            if($USER){Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Trigger $trg -Settings $STSet -Principal $STPrin -ea Stop}
                            else{Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Trigger $trg -Settings $STSet  -ea Stop}
                        }
                        catch{return "Error: $($_.Exception.Message)"}
                    }
                # WEEKLY TASK
                    'Weekly'{
                        try{
                            $trg= New-ScheduledTaskTrigger -Weekly -At $Time -DaysOfWeek $WeekDays -WeeksInterval $Interval
                            if($USER){Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Trigger $trg -Settings $STSet -Principal $STPrin -ea Stop}
                            else{Register-ScheduledTask -TaskName $TaskName -Description "Task Scheduled for $Path" -Action $task -Trigger $trg -Settings $STSet  -ea Stop}
                        }
                        catch{return "Error: $($_.Exception.Message)"}
                    }
                } # switch end
            }
        } # if path exist check
        else
        {
            Write-Host "$Path not valid Path or Provide a ps1 file." -fore Yellow
            return "Error: $Path not valid Path or Provide a ps1 file."
        }
       
    }catch{
        Write-Host $_.Exception.Message
        return "Error: $($_.Exception.Message)"
    }
  }
}


## SCHEDULE TASK
$res = ''
switch ($Duration)
{
    'Once' {
        $res = Schedule-Task -Path $Path -TaskName $TaskName -Duration Once -Time (Get-Date -Date $Time) -USER $USER;
        break;
     }
    'Daily'{
        $res = Schedule-Task -Path $Path -TaskName $TaskName -Duration Daily -Interval ([int]$Interval) -RecurEvery $RecurEvery -RecurInterval $RecurInterval -Time (Get-Date -Date $Time) -USER $USER;
        break;
     }
    'Weekly'{
        $res = Schedule-Task -Path $Path -TaskName $TaskName -Duration Weekly -Interval ([int]$Interval) -WeekDays ($WeekDays -split " ") -Time (Get-Date -Date $Time) -USER $USER;
        break;
     }
    Default {break;}
}
