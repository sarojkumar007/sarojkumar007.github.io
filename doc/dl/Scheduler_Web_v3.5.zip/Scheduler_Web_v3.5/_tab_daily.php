<?php

    $MainModule = __DIR__."\Schedule_Task_PHP.ps1";
    $PingServerModulePath = __DIR__."\Ping_Servers_PHP.ps1";

    $scriptPath = '';
    $serverPath = '';

    // Get Local User
    exec('echo %USERNAME%',$user,$u_err);

    if(isset($_POST['scheduleDaily'])){
        $daily_scriptFile = $_FILES['daily_scriptFile'];
        $daily_serverFile = $_FILES['daily_serverFile'];
        $daily_taskName = $_POST['daily_taskName'];
        $daily_date = $_POST['daily_date'];
        $daily_time = $_POST['daily_time'];
        $daily_interval = $_POST['daily_interval'];
        $daily_repeatEvery = $_POST['daily_repeatEvery'];
        $daily_repeatInterval = $_POST['daily_repeatInterval'];
        $daily_user = $_POST['daily_user'];


        $daily_TaskPath = __DIR__."\scripts\\".$daily_taskName."\\";

        if(file_exists($daily_TaskPath)){
            echo "<script>alert('Folder with same TaskName exists.')</script>";
            header("Refresh:1");
        }
        else{
            mkdir($daily_TaskPath);

            $script_ext = pathinfo($daily_scriptFile['name'],PATHINFO_EXTENSION);
            if($daily_serverFile['name']){$server_ext = pathinfo($daily_serverFile['name'],PATHINFO_EXTENSION);}

            $script_filename = $_FILES['daily_scriptFile']['name'];
            if($daily_serverFile['name']){$server_filename = $_FILES['daily_serverFile']['name'];}
            
            $scriptPath = $daily_TaskPath.$script_filename;
            if($daily_serverFile['name']){$serverPath = $daily_TaskPath.$server_filename;}

            $allowed_script_ext = array("ps1");
            if($daily_serverFile['name']){$allowed_server_ext = array("txt","csv");}

            if (!in_array($script_ext, $allowed_script_ext)) {
                echo '
                <script>
                    alert("Please upload file in .ps1 format");
                </script>
                ';
                header("Refresh:1");
            }
            if ($daily_serverFile['name'] and (!in_array($server_ext, $allowed_server_ext))) {
                echo '
                <script>
                    alert("Please upload file in .txt and .csv format");
                </script>
                ';
                header("Refresh:1");
            }
            move_uploaded_file($daily_scriptFile['tmp_name'],$scriptPath);
            if($daily_serverFile['name']){move_uploaded_file($daily_serverFile['tmp_name'],$serverPath);}
        }

        $command = 'powershell -File "'.$MainModule.'" -Path "'.$scriptPath.'" -TaskName "'.$daily_taskName.'" -Duration Daily -Interval "'.$daily_interval.'" -Time "'.$daily_date.' '.$daily_time.'" -RecurEvery "'.$daily_repeatEvery.'" -RecurInterval "'.$daily_repeatInterval.'" -USER "'.$daily_user.'"';

        exec($command, $output, $err);

        if($err){
            $D_MSG = '<div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="row" style="align-items: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                    <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                    <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                </svg>
                <strong>Failed!</strong>&nbsp;Task Failed, Try again.
            </div>
            </div>';
        }else{

            date_default_timezone_set("Asia/Kolkata");
            $date = date('Y-m-d H:i:s', time());
            $db = new DBConnect\CRUD("localhost","root","","scheduler");
            $table = "report";
            $colArr = array('TaskName','Author','isDeleted','Created');
            $valArr = array($daily_taskName,$user[0],'0',$date);

            $item = $db->INSERT_VAL($table,$colArr,$valArr);

            $D_MSG = '<div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="row" style="align-items: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                    <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                    <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
                </svg>
                <strong>Success!</strong>&nbsp;Daily Task Scheduled Successfully.
            </div>
            </div>';
        }
    }
?>

<!-- modal for USERS and GROUPS -->
<div class="modal fade" id="daily_user_select" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p><strong>Select User and Group</strong></p>
                <hr>
                <select name="daily_selected_user" id="daily_selected_user" class="form-control">
                <?php
                    exec('powershell.exe -command (get-localgroup).name+(get-localuser).name',$users,$err);
                    if($err){echo "Can't Load Users or Groups";}
                    $users = array_merge($users,array("SYSTEM","LOCAL SERVICE","NETWORK SERVICE"));
                    foreach($users as $u){
                        echo '<option value="'.$u.'">'.$u.'</option>';
                    }
                ?>
                </select>
            </div>
            <div class="modal-footer">
                <button type="submit" name="daily_user_select_btn" id="daily_user_select_btn" class="btn btn-primary" data-dismiss="modal">Select</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- MAIN CODE -->
<div class="container">
    <?php if(isset($D_MSG)){echo '<div class="message_box">'.$D_MSG.'</div>';}?>
    <div class="task_title">
        <span style="margin-right: 10px;">
            <i data-feather="clock" class="font-weight-bold"></i>
        </span>
        <h2 class="lead font-weight-bold">Schedule a Task for Daily</h2>
    </div>      
    <hr>
    <form action="?tab=daily" method="POST"  enctype="multipart/form-data">
    <p><strong class="lead text-danger">*</strong> Script Path (<small>Provide PowerShell file(.ps1) only</small>)</p>
    <div class="row form-group">
        <div class="col col-md-10">
            <input type="text" name="daily_scriptPathDisplay" id="daily_scriptPathDisplay" class="form-control" value="<?php if(isset($_SESSION['daily_script_file'])){echo $_SESSION['daily_script_file'];}?>" required readonly spellcheck="false" autocomplete="off">
        </div>
        <div class="col col-md-2">
            <input type="file" name="daily_scriptFile" id="daily_scriptFile" class="d-none" required>
            <label for="daily_scriptFile" class="btn btn-light">Browse</label>
        </div>
    </div>
    <p>Servers File (<small>Provide .txt or .csv file only</small>)</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="daily_serverPathDisplay" id="daily_serverPathDisplay" class="form-control" value="<?php if(isset($_SESSION['daily_server_file'])){echo $_SESSION['daily_server_file'];}?>" readonly spellcheck="false" autocomplete="off">
        </div>
        <div class="col col-md-3">
            <input type="file" name="daily_serverFile" id="daily_serverFile" class="d-none">
            <label for="daily_serverFile" class="btn btn-light">Choose Server File</label>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-6 form-group">
            <p><strong class="lead text-danger">*</strong> Task Name</p>
            <input type="text" name="daily_taskName" id="daily_taskName" class="form-control" required spellcheck="false" autocomplete="off" />
        </div>
        <div class="col col-md-6 form-group">
            <p class=""><strong class="lead text-danger">*</strong> Select Date (<small>MM/DD/YYYY</small>) and Time (<small>24Hrs</small>) (UTC +5:30):</p>
            <div class="row form-group pl-3">
                <input type="text" placeholder="MM/DD/YYYY" name="daily_date" id="daily_date" class="form-control col col-md-7" required autocomplete="off">
                <input type="text" placeholder="HH:mm" name="daily_time" id="daily_time" class="form-control col col-md-5" required autocomplete="off">
            </div>
        </div>
    </div>
    <div class="row form-group">
        <p class="col col-md-3"><strong class="lead text-danger">*</strong> Recur Every:</p>
        <input type="number" name="daily_interval" id="daily_interval" min="1" value="1" class="col col-md-2 form-control" required  autocomplete="off">
        <p class="col col-md-3">Day(s)</p>
    </div>
    <p class="font-weight-bold">Advanced Settings</p>
    <hr>
    <div class="row form-group">
        <p class="col col-md-3">Repeat Task Every:</p>
        <select name="daily_repeatInterval" id="daily_repeatInterval" class="col col-md-3 form-control">
            <option value="5 Minutes">5 Minutes</option>
            <option value="10 Minutes">10 Minutes</option>
            <option value="15 Minutes">15 Minutes</option>
            <option value="30 Minutes">30 Minutes</option>
            <option value="1 Hour" selected>1 Hour</option>
        </select>
        <p class="col col-md-3">for a duration of:</p>
        <select name="daily_repeatEvery" id="daily_repeatEvery" class="form-control col col-md-3">
            <option value="Indefinitely">Indefinitely</option>
            <option value="15 Minutes">15 Minutes</option>
            <option value="30 Minutes">30 Minutes</option>
            <option value="1 Hour">1 Hour</option>
            <option value="12 Hours">12 Hours</option>
            <option value="1 Day" selected>1 Day</option>
        </select>
    </div>
    <p>When running this task, use this following account:</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="daily_user" id="daily_user" spellcheck="false" class="form-control" placeholder="<Default User> or Change" value="<?php echo $user[0]; ?>" readonly>
        </div>
        <div class="col col-md-3">
            <a class="btn btn-light" data-toggle="modal" data-target="#daily_user_select">Change User or Group</a>
        </div>
    </div>
    <!-- ----------------------- -->
    <div class="row" style="margin-top: 60px;">
        <button type="submit" name="scheduleDaily" class="btn btn-primary mr-3">Schedule</button>
        <button type="reset" class="btn btn-light">Cancel</button>
    </div>
    </form>
</div>
<script>
    $(document).ready(function(){
        $("#daily_user_select_btn").on('click',function(){
            $("#daily_user").val($("#daily_selected_user").val());
        })
        document.getElementById('daily_scriptFile').onchange = function(e){
            document.getElementById('daily_scriptPathDisplay').value = e.target.files[0].name
        }
        document.getElementById('daily_serverFile').onchange = function(e){
            document.getElementById('daily_serverPathDisplay').value = e.target.files[0].name
        }
    });
</script>

