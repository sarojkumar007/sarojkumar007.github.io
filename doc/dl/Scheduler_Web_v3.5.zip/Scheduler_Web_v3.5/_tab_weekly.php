<?php

$MainModule = __DIR__."\Schedule_Task_PHP.ps1";
$PingServerModulePath = __DIR__."\Ping_Servers_PHP.ps1";

$scriptPath = '';
$serverPath = '';

// Get Local User
exec('echo %USERNAME%',$user,$u_err);

if(isset($_POST['weekly_uploadScriptFile'])){
    $f = $_FILES['weekly_scriptFile'];

    $uploadPath = 'scripts\\';
    $ext = pathinfo($_FILES['weekly_scriptFile']['name'],PATHINFO_EXTENSION);
    $filename = $_FILES['weekly_scriptFile']['name'];
    $scriptPath = $uploadPath.$filename;			
    
    $allowed_csv_ext=array("ps1");
    if ( !in_array($ext, $allowed_csv_ext)) {
        echo '<script>alert("Please upload file in .ps1 format");</script>';
        header("Refresh:1");
    }else{
        if(file_exists($scriptPath)){
            // echo '<script>alert("File with this name already exists");</script>';
            unlink($scriptPath);
        }
        move_uploaded_file($_FILES['weekly_scriptFile']['tmp_name'], $scriptPath);
        
        $_SESSION['weekly_script_file'] = __DIR__.'\\'.$scriptPath;
    }
}

if(isset($_POST['weekly_uploadServerFile'])){
    $serverFile = $_FILES['weekly_serverFile'];

    $uploadPath = 'scripts\\';
    $ext = pathinfo($_FILES['weekly_serverFile']['name'],PATHINFO_EXTENSION);
    $filename = $_FILES['weekly_serverFile']['name'];
    $serverPath = $uploadPath.$filename;			
    
    $allowed_csv_ext=array("txt","csv");
    if ( !in_array($ext, $allowed_csv_ext)) {		
        echo '<script>alert("Please upload file in .txt or .csv format");</script>';
        header("Refresh:1");
    }else{
        if(file_exists($serverPath)){
            // echo '<script>alert("File with this name already exists");</script>';
            unlink($serverPath);
        }
        move_uploaded_file($_FILES['weekly_serverFile']['tmp_name'], $serverPath);
        
        $_SESSION['weekly_server_file'] = __DIR__.'\\'.$serverPath;
    }
}

if(isset($_POST['scheduleWeekly'])){
    if(!isset($_POST['weekly_days'])){
        echo '<script>
            alert("Please select atleast 1 Day");
            history.back(-1);
        </script>';
        exit();
    }

    $weekly_scriptFile = $_FILES['weekly_scriptFile'];
    $weekly_serverFile = $_FILES['weekly_serverFile'];
    $weekly_taskName = $_POST['weekly_taskName'];
    $weekly_date = $_POST['weekly_date'];
    $weekly_time = $_POST['weekly_time'];
    $weekly_interval = $_POST['weekly_interval'];
    $wds = '"'.implode(' ',$_POST['weekly_days']).'"';
    $weekly_user = $_POST['weekly_user'];

    $weekly_TaskPath = __DIR__."\scripts\\".$weekly_taskName."\\";

    if(file_exists($weekly_TaskPath)){
        echo "<script>alert('Folder with same TaskName exists.')</script>";
        header("Refresh:1");
    }
    else{
        mkdir($weekly_TaskPath);

        $script_ext = pathinfo($weekly_scriptFile['name'],PATHINFO_EXTENSION);
        if($weekly_serverFile['name']){$server_ext = pathinfo($weekly_serverFile['name'],PATHINFO_EXTENSION);}

        $script_filename = $_FILES['weekly_scriptFile']['name'];
        if($weekly_serverFile['name']){$server_filename = $_FILES['weekly_serverFile']['name'];}
        
        $scriptPath = $weekly_TaskPath.$script_filename;
        if($weekly_serverFile['name']){$serverPath = $weekly_TaskPath.$server_filename;}

        $allowed_script_ext = array("ps1");
        if($weekly_serverFile['name']){$allowed_server_ext = array("txt","csv");}

        if (!in_array($script_ext, $allowed_script_ext)) {
            echo '
            <script>
                alert("Please upload file in .ps1 format");
            </script>
            ';
            header("Refresh:1");
        }
        if ($weekly_serverFile['name'] and (!in_array($server_ext, $allowed_server_ext))) {
            echo '
            <script>
                alert("Please upload file in .txt and .csv format");
            </script>
            ';
            header("Refresh:1");
        }
        move_uploaded_file($weekly_scriptFile['tmp_name'],$scriptPath);
        if($weekly_serverFile['name']){move_uploaded_file($weekly_serverFile['tmp_name'],$serverPath);}
    }

    $w_command = 'powershell -File "'.$MainModule.'" -Path "'.$scriptPath.'" -TaskName "'.$weekly_taskName.'" -Duration Weekly -Interval "'.$weekly_interval.'" -Time "'.$weekly_date.' '.$weekly_time.'" -WeekDays '.$wds.' -USER "'.$weekly_user.'"';
    
    exec($w_command, $output, $err);

    if($err){
        $W_MSG = '<div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <div class="row" style="align-items: center;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
            </svg>
            <strong>Failed!</strong>&nbsp;Task Failed, Try again.
        </div>
        </div>';
    }else{

        date_default_timezone_set("Asia/Kolkata");
        $date = date('Y-m-d H:i:s', time());
        $db = new DBConnect\CRUD("localhost","root","","scheduler");
        $table = "report";
        $colArr = array('TaskName','Author','isDeleted','Created');
        $valArr = array($weekly_taskName,$user[0],'0',$date);

        $item = $db->INSERT_VAL($table,$colArr,$valArr);
        
        $W_MSG = '<div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <div class="row" style="align-items: center;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-circle" viewBox="0 0 16 16">
                <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z"/>
                <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z"/>
            </svg>
            <strong>Success!</strong>&nbsp;Weekly Task Scheduled Successfully.
        </div>
        </div>';
    }
    
}
?>

<!-- modal for USERS and GROUPS -->
<div class="modal fade" id="weekly_user_select" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p><strong>Select User and Group</strong></p>
                <hr>
                <select name="weekly_selected_user" id="weekly_selected_user" class="form-control">
                <?php
                    exec('powershell.exe -command (get-localgroup).name+(get-localuser).name',$users,$err);
                    if($err){echo "Can't Load Users or Groups";}
                    $users = array_merge($users,array("SYSTEM","LOCAL SERVICE","NETWORK SERVICE"));
                    foreach($users as $u){
                        echo '<option value="'.$u.'">'.$u.'</option>';
                    }
                ?>
                </select>
            </div>
            <div class="modal-footer">
                <button type="submit" name="weekly_user_select_btn" id="weekly_user_select_btn" class="btn btn-primary" data-dismiss="modal">Select</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- MAIN CODE -->
<div class="container">
    <?php if(isset($W_MSG)){echo '<div class="message_box">'.$W_MSG.'</div>';}?>
    <div class="task_title">
        <span style="margin-right: 10px;">
            <i data-feather="clock" class="font-weight-bold"></i>
        </span>
        <h2 class="lead font-weight-bold">Schedule a Task for Weekly</h2>
    </div>      
    <hr>
    <form action="?tab=weekly" method="POST" id="weekly_form" enctype="multipart/form-data">
    <p><strong class="lead text-danger">*</strong> Script Path (<small>Provide PowerShell file(.ps1) only</small>)</p>
    <div class="row form-group">
        <div class="col col-md-10">
            <input type="text" name="weekly_scriptPathDisplay" id="weekly_scriptPathDisplay" class="form-control" value="<?php if(isset($_SESSION['weekly_script_file'])){echo $_SESSION['weekly_script_file'];}?>" required readonly spellcheck="false" autocomplete="off">
        </div>
        <div class="col col-md-2">
            <input type="file" name="weekly_scriptFile" id="weekly_scriptFile" class="d-none" required accept="PowerShell Files(*.ps1), .ps1">
            <label for="weekly_scriptFile" class="btn btn-light">Browse</label>
        </div>
    </div>
    <p>Servers File (<small>Provide .txt or .csv file only</small>)</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="weekly_serverPathDisplay" id="weekly_serverPathDisplay" class="form-control" value="<?php if(isset($_SESSION['weekly_server_file'])){echo $_SESSION['weekly_server_file'];}?>" readonly spellcheck="false" autocomplete="off">
        </div>
        <div class="col col-md-3">
            <input type="file" name="weekly_serverFile" id="weekly_serverFile" class="d-none" accept="text/*,.txt,.csv">
            <label for="weekly_serverFile" class="btn btn-light">Upload Server File</label>
        </div>
    </div>
    <div class="row">
        <div class="col col-md-6 form-group">
            <p><strong class="lead text-danger">*</strong> Task Name</p>
            <input type="text" name="weekly_taskName" id="weekly_taskName" class="form-control" required spellcheck="false" autocomplete="off"/>
        </div>
        <div class="col col-md-6 form-group">
            <p class=""><strong class="lead text-danger">*</strong> Select Date (<small>MM/DD/YYYY</small>) and Time (<small>24Hrs</small>) (UTC +5:30):</p>
            <div class="row form-group pl-3">
                <input type="text" placeholder="MM/DD/YYYY" name="weekly_date" id="weekly_date" class="form-control col col-md-7" required  autocomplete="off" >
                <input type="text" placeholder="HH:mm"  name="weekly_time" id="weekly_time" class="form-control col col-md-5" required  autocomplete="off">
            </div>
        </div>
    </div>
    <div class="row form-group">
        <p class="col col-md-3"><strong class="lead text-danger">*</strong> Recur Every:</p>
        <input type="number" name="weekly_interval" id="weekly_interval" min="1" value="1" class="col col-md-2 form-control" required  autocomplete="off">
        <p class="col col-md-3">weeks</p> 
    </div>
    <p>On:</p>
    <div class="row form-group px-3">
        <?php
            $weekDays = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
            for ($wd=0; $wd < count($weekDays); $wd++) { 
                echo '
                <div class="form-check col col-md-3">
                    <input class="form-check-input" name="weekly_days[]" type="checkbox" value="'.$weekDays[$wd].'" id="weekly_day'.$wd.'">
                    <label class="form-check-label" for="weekly_day'.$wd.'">
                    '.$weekDays[$wd].'
                    </label>
                </div>';
            }
        ?>
    </div>    
    <p class="font-weight-bold">Advanced Settings</p>
    <hr>
    <p>When running this task, use this following account:</p>
    <div class="row form-group">
        <div class="col col-md-9">
            <input type="text" name="weekly_user" id="weekly_user" spellcheck="false" class="form-control" placeholder="<Default User> or Change" value="<?php echo $user[0]; ?>" readonly>
        </div>
        <div class="col col-md-3">
            <a class="btn btn-light" data-toggle="modal" data-target="#weekly_user_select">Change User or Group</a>
        </div>
    </div>
    <div class="row" style="margin-top: 60px;">
        <button type="submit" value="#" name="scheduleWeekly" class="btn btn-primary mr-3">Schedule</button>
        <button type="reset" class="btn btn-light">Cancel</button>
    </div>
    </form>
</div>

<script>
    $(document).ready(function(){
        $("#weekly_user_select_btn").on('click',function(){
            $("#weekly_user").val($("#weekly_selected_user").val());
        })
        document.getElementById('weekly_scriptFile').onchange = function(e){
            document.getElementById('weekly_scriptPathDisplay').value = e.target.files[0].name
        }
        document.getElementById('weekly_serverFile').onchange = function(e){
            document.getElementById('weekly_serverPathDisplay').value = e.target.files[0].name
        }
    });
</script>