<?php
    include('_config.php');
    $db = new DBConnect\CRUD("localhost","root","","scheduler");
    $table = "report";
    
    if(isset($_POST['TaskName'])){
        $tsk = $_POST['TaskName'];

        $TaskPath = __DIR__."\scripts\\".$tsk."\\";

        exec('powershell.exe -command Unregister-ScheduledTask -TaskName "'.$tsk.'" -Confirm:$false',$success,$err);
        
        function rmdir_recursive($dir) {
            foreach(scandir($dir) as $file) {
                if ('.' === $file || '..' === $file) continue;
                if (is_dir("$dir/$file")) rmdir_recursive("$dir/$file");
                else unlink("$dir/$file");
            }
            rmdir($dir);
        }

        if(!$err){

            $colArr = array('isDeleted');
            $valArr = array('1');
            $condition = 'WHERE TaskName="'.$tsk.'"';

            $update = $db->UPDATE_DATA($table,$colArr,$valArr,$condition);

            if(file_exists($TaskPath)){
                rmdir_recursive($TaskPath);
            }
            echo 'Task deleted from Scheduler successfully';
        }
    }
?>