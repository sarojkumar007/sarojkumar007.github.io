<?php
namespace DBConnect {
	class DBConnection{
		public $DB;
		protected $host;
		protected $uname;
		protected $pwd;
		protected $dbname;

		function __construct($host,$uname,$pwd,$dbname){
			$this->host = $host;
			$this->uname = $uname;
			$this->pwd = $pwd;
			$this->dbname = $dbname;

			$this->DB = mysqli_connect($this->host,$this->uname,$this->pwd,$this->dbname);
			if(!$this->DB){
				echo "DB Connected failed!";
				exit;
			}
		}
	}

	class CRUD extends DBConnection{
		
		// @READ/SELECT
		public function FETCH_DATA($table,$column,$condition,$isArr=0){
			$this->table = $table;
			$this->colArrs = $column;
			$this->condition = $condition;
			$this->ArrResults = array();

			$query = "SELECT ".implode(", ",$this->colArrs)." FROM ".$this->table." ".$this->condition;

			// return $query;

			if(!$res = mysqli_query($this->DB, $query)){
				mysqli_error($this->DB);
			}
			else{
				if($isArr == 1){
					$i = 0;
					while($results = mysqli_fetch_assoc($res)){
						$this->ArrResults[$i] = filter_var_array($results,FILTER_UNSAFE_RAW);
						$i++;
					}
					return $this->ArrResults;
				}
				else{
					return $res;
				}
			}
		}

		// @UPDATE
		public function UPDATE_DATA($table, $colArr, $valArr, $condition){
			$this->table = $table;
			$this->colArrs = $colArr;
			$this->valArrs = $valArr;
			$this->condition = $condition;

			$dataStr = array();

			for ($i=0; $i < count($colArr); $i++) {
				array_push($dataStr, " ".$colArr[$i]." = '".$valArr[$i]."'");
			}

			$query = "UPDATE ".$this->table." SET ".implode(',',$dataStr)." ".$condition;

			// return $query;

			if(!$res = mysqli_query($this->DB, $query)){
				mysqli_error($this->DB);
			}
			else{
				// result gives 1 always even that row does not exist.
				return TRUE;
			}
		}

		// @DELETE
		public function DELETE_ROWS($table,$condition){
			$this->table = $table;
			// $this->colArrs = $this->$column;

			$query = "DELETE FROM ".$this->table." ".$condition;

			// return $query;

			if(!$res = mysqli_query($this->DB, $query)){
				mysqli_error($this->DB);
			}
			else{
				return TRUE;
			}
		}

		// @CREATE		
		public function CREATE_TABLE($table,$cols, $dt){
			$this->table = $table;
			$this->cols = $cols;
			$this->dt = $dt;

			$tabData = array();

			for ($i=0; $i < count($cols); $i++) { 
				array_push($tabData, $cols[$i]." ".$dt[$i]);
			}

			$query = "CREATE TABLE ".$this->table." (".implode(', ',$tabData).")";

			return "<br/>".$query;
			// return "<br/>TABLE ".$this->table." will be created shortly.";
		}
		
		// @INSERT
		public function INSERT_VAL($table, $cols, $vals){
			$this->table = $table;
			$this->cols = $cols;
			$this->vals = $vals;

			// error while using $this->PROP
			$query = "INSERT INTO ".$this->table." (".implode(", ",$cols).") VALUES ('".implode("', '",$vals)."')";

			// return "<br/>".$query;
			// exit;

			if($res = mysqli_query($this->DB, $query)){
				return TRUE;
			}
			else{
				return FALSE;
			}
		} // func end

	}// class CRUD end

} // namespace end
?>