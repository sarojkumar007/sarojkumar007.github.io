#[String]$LogFile,
Param(
    [String]$SCRIPT,
    [String]$SERVERS_FILE,
    [Parameter(Mandatory=$true)][string]$Path,
    [Parameter(Mandatory=$true)][string]$TaskName,
    [Parameter(Mandatory=$true)][ValidateSet("Once","Daily","Weekly","Monthly")][String]$Duration,
    [String]$Interval,
    [String]$WeekDays,
    [Parameter(Mandatory=$true)][String]$Time,
    [ValidateSet("Indefinitely","15 Minutes","30 Minutes","1 Hour","12 Hours","1 Day")][String]$RecurEvery,
    [ValidateSet("5 Minutes","10 Minutes","15 Minutes","30 Minutes","1 Hour")][String]$RecurInterval
)

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

########################################################
$ModuleFileName = Split-Path "$SCRIPT" -Leaf
$ScriptFileName = Split-Path "$Path" -Leaf
$SERVERS = Get-Content $SERVERS_FILE

Foreach ($SERVER in $SERVERS)
{
    If(Test-WSMan -ComputerName $SERVER -EA 0)
    {
        $ModulePath = "\\$SERVER\c$\TaskScheduler\$ModuleFileName"
        $ScriptPath = "\\$SERVER\c$\TaskScheduler\$ScriptFileName"

        "Configuring the task on server $SERVER..."
        if((Test-Path $ModulePath) -and (Test-Path $ScriptPath)){}
        else{
            New-Item -Path "\\$SERVER\c$\TaskScheduler" -ItemType 'Directory' -Force
            Copy-Item -Path "$SCRIPT" -Destination $ModulePath -Force
            Copy-Item -Path "$Path" -Destination $ScriptPath -Force
        }
        $Path = $ScriptPath
        #########################
        #Invoke-Command -ComputerName $SERVER -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$Time,$WeekDays,$RecurEvery,$RecurInterval)
        
        switch ($Duration)
        {
            'Once' {
                Invoke-Command -ComputerName $SERVER -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,"DUMP",$Time,"DUMP","Indefinitely")
                break;
             }
            'Daily'{
                Invoke-Command -ComputerName $SERVER -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$Time,"DUMP",$RecurEvery,$RecurInterval)
                break;
             }
            'Weekly'{
                Invoke-Command -ComputerName $SERVER -FilePath $ModulePath -ArgumentList ($Path,$TaskName,$Duration,$Interval,$Time,$WeekDays)
                break;
             }
            'Monthly'{break;}
            Default {break;}
        }
        #########################
        # WRITE TO CSV HERE
    }
    Else 
    {
        write-host "$SERVER is not available"
    }
}