﻿Param(
    [String]$ServerFile
)

if(Test-Path $ServerFile)
{
    $servers = Get-Content $ServerFile
}
foreach($server in $servers){
    if(Test-Connection $server -Count 1 -Quiet)
    {
        Write-Host $server
    }
}